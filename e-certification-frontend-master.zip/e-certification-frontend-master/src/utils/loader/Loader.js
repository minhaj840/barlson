import { Modal } from "react-bootstrap";
import React, { memo } from "react";
import { SyncLoader } from "react-spinners";

function Loader({ loader = false }) {
  return (
    <>
      <Modal show={loader} animation={false} backdrop="static" centered>
        <Modal.Header>
          <Modal.Title>Loading...</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="d-flex justify-content-center">
            <SyncLoader size={12} loading={loader} color="red" />
          </div>
        </Modal.Body>
        <Modal.Footer></Modal.Footer>
      </Modal>
    </>
  );
}

export default memo(Loader);
