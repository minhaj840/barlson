// const base64Data = Buffer.from(bufferData).toString("base64");
// const dataUrl = `data:application/pdf;base64,${base64Data}`;
// console.log(data?.data?.certificate);

// const date = moment(data?.data?.startDate);
// const formattedStartDate = date.format("DD MMM YYYY");

// // get end date
// const startDate = moment(data?.data?.startDate);
// const match = data?.data?.duration.match(/\d+/);
// const durationMonths = parseInt(match[0], 10);
// const endDate = startDate.clone().add(durationMonths, "months");
// const formattedEndDate = endDate.format("DD MMM YYYY");
