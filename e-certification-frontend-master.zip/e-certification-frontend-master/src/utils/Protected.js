import { Navigate, Outlet } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { isAutheticated } from "./isAuth";
// isLoggedIn?.token ?

export const Protected = () => {
  const location = useLocation();
  const isLoggedIn = isAutheticated();

  return (
    <>
      { isLoggedIn?.token? (
        <Outlet />
      ) : (
        <Navigate
          to="/login"
          redirect="/login"
          replace
          state={{ from: location }}
        />
      )}
    </>
  );
};
