const campusAmbassador =  {
    email:"",
    

}