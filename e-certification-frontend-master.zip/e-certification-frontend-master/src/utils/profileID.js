import { isAutheticated } from "./isAuth";
const { data } = isAutheticated();
const jsonData = JSON.parse(localStorage.getItem("IdCard"));
export const ambassadorId = jsonData?.data?._id || null;
export const studentID = data?.data?.studentID;

export const logoutAmabassador = () => {
  localStorage.removeItem("IdCard");
  window.location.reload();
  return true;
};
