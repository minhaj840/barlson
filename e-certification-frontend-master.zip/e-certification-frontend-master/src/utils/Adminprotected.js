import { Navigate, Outlet } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { isAdminAutheticated } from "./isAuth";

export const AdminProtected = () => {
    const location = useLocation();
    const isLoggedIn = isAdminAutheticated();

    return (
        <>
            {isLoggedIn?.token ? (
                <Outlet />
            ) : (
                <Navigate to="/" redirect="/" replace state={{ from: location }} />
            )}
        </>
    );
};
