module.exports.randomID = (digitLength) => {
    let string = "";
    const digits = "0123456789";
    for (let i = 0; i < digitLength; i++) {
      string += digits[Math.floor(Math.random() * digitLength)];
    }
  
    return string;
  };
  