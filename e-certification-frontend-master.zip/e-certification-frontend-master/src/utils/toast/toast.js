import { toast } from "react-hot-toast";

export const toastSuccess = (text) => {
  toast.success(text, {
    duration: 5000,
  });
};
export const toastError = (error) => {
  toast.error(error, {
    duration: 5000,
  });
};
export const toastApiError = (error) => {
  toast.error(error?.response?.data?.message || error?.message, {
    duration: 5000,
  });
};
