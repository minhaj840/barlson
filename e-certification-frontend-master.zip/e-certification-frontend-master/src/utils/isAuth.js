export const isAutheticated = () => {
  if (typeof window == "undefined") {
    return true;
  }
  if (localStorage.getItem("studentAuth")) {
    return JSON.parse(localStorage.getItem("studentAuth"));
  } else {
    console.log(JSON.parse(localStorage.getItem("studentAuth")));
    return false;
  }
};

export const signout = () => {
  localStorage.removeItem("studentAuth");
  window.location.reload();
  return true;
};



export const isAdminAutheticated = () => {
  if (typeof window == "undefined") {
    return true;
  }
  if (localStorage.getItem("AdminAuthInt")) {
    return JSON.parse(localStorage.getItem("AdminAuthInt"));
  } else {
    console.log(JSON.parse(localStorage.getItem("AdminAuthInt")));
    return false;
  }
};

export const signoutAdmin = () => {
  localStorage.removeItem("AdminAuthInt");
  window.location.reload()
  return true;
};



// for hackthon
export const isHackthonAutheticated = () => {
  if (typeof window == "undefined") {
    return true;
  }
  if (localStorage.getItem("studentHackthon")) {
    return JSON.parse(localStorage.getItem("studentHackthon"));
  } else {
    console.log(JSON.parse(localStorage.getItem("studentHackthon")));
    return false;
  }
};

export const signoutHackthon = () => {
  localStorage.removeItem("studentHackthon");
  window.location.reload()
  return true;
};
