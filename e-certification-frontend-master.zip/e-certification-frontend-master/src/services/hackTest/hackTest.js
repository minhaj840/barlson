import {
  isAdminAutheticated,
  isHackthonAutheticated,
} from "../../utils/isAuth";
import { Axios } from "../axios";

const { token } = isHackthonAutheticated();
const adminToken = isAdminAutheticated();

// admin control
export const submitTestTime = async () => {
  return Axios.get("/hackTest/completeTest", {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};
export const getQuestion = async () => {
  return Axios.get("/hackTest/getQuestion", {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};

// admin control
export const submitAnswerToDb = async ({ ...data }) => {
  return Axios.post("/hackTest/submitAnswer", data, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};
// admin control add guidline
export const addGuideLine = async ({ ...data }) => {
  return Axios.post("/hackTest/guideline", data, {
    headers: {
      Authorization: `Bearer ${adminToken?.token}`,
    },
  });
};
export const getGuideLine = async () => {
  return Axios.get("/hackTest/guideline", {
    headers: {
      Authorization: `Bearer ${adminToken?.token}`,
    },
  });
};

// end

// get status of test
export const getStatusTest = async () => {
  return Axios.get("/hackTest/getStatusTest", {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};

// get all student
export const allStudent = async () => {
  return Axios.get("/hackTest/allStudent", {
    headers: {
      Authorization: `Bearer ${adminToken?.token}`,
    },
  });
};
export const allStudentCompletedTest = async () => {
  return Axios.get("/hackTest/allStudentCompletedTest", {
    headers: {
      Authorization: `Bearer ${adminToken?.token}`,
    },
  });
};
