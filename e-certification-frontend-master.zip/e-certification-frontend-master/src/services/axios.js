import axios from "axios";
import { API, APICYCLIC } from "./api";

export const Axios = axios.create({
    baseURL: API,
});
export const AxiosCyclic = axios.create({
    baseURL: APICYCLIC,
});
