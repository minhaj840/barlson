import { isAdminAutheticated } from "../../utils/isAuth";
import { Axios } from "../axios";

//Admin login to verify itself
const { token } = isAdminAutheticated();


export const getAllCampusAmbassador = async () => {
    return Axios.get("/ambassdor/getAll",{
        headers: {
            Authorization: `Bearer ${token}`,
          },
    });
  };

  export const updateAmbassadorStatus = async (id) => {
    return Axios.get(`/ambassdor/status/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  };

  export const AmbassadorStatusProfile = async (id) => {
    return Axios.get(`/ambassdor/profile/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  };
  
  export const deleteAmbassador = async (id) => {
    return Axios.delete(`/ambassdor/delete/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  };