import { isAdminAutheticated } from "../../utils/isAuth";
import { Axios } from "../axios";

//Admin login to verify itself

const { token} = isAdminAutheticated();


export const Login = async ({ ...data }) => {
  return Axios.post("/auth/login", data);
};

// //  admin can add student // admin control

export const addStudent = async ({...data}) => {
  return Axios.post("/student/add", data, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};

// get all student // admin control

export const getAllStudent = async () => {
  return Axios.get("/student/getAll", {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};
