// export const API = "http://localhost:5000/api";
// export const APICYCLIC = "http://localhost:5000/api";

export const APICYCLIC = "https://blue-thoughtful-cape-buffalo.cyclic.app/api";
export const API =
  "https://3vteqvw4rb.execute-api.ap-south-1.amazonaws.com/prod/api";
