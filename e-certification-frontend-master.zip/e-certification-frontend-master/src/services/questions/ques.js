import { isAdminAutheticated } from "../../utils/isAuth";
import { Axios } from "../axios";

const { token } = isAdminAutheticated();

// admin control
export const addQuestionToDb = async ({ ...data }) => {
  return Axios.post("/question/add", data, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};
export const getQuestionToDb = async () => {
  return Axios.get("/question/getAll", {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};

// admin control
export const deleteQuestionToDb = async (id) => {
  return Axios.delete(`/question/delete/${id}`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};
