import { isAdminAutheticated, isAutheticated } from "../../utils/isAuth";
import { Axios } from "../axios";

const studentToken = isAutheticated();

const { token } = isAdminAutheticated();

// admin control
export const updateStudentStatus = async (id) => {
  return Axios.get(`/student/update/status/${id}`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};

// admin control
export const deleteStudent = async (id) => {
  return Axios.delete(`/student/delete/${id}`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};



// for student
export const getStudentProfile = async (id) => {
  return Axios.get(`/student/profile/${id}`, {
    headers: {
      Authorization: `Bearer ${studentToken?.token}`,
    },
  });
};
