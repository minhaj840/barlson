import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  open: false,
  student: {},
  render: Math.random(),
};

export const toggleMenuReducer = createSlice({
  name: "global",
  initialState,
  reducers: {
    toggleMenu: (state, action) => {
      return { ...state, open: action.payload.open };
    },

    saveToLocalStorage: (state, action) => {
      localStorage.setItem(
        "IdCard",
        JSON.stringify({ data: action.payload.data })
      );
      return { ...state, student: action.payload.open };
    },
    loginRender: (state, action) => {
      return { ...state, render: Math.random() };
    },
  },
});

// Action creators are generated for each case reducer function
export const { toggleMenu, saveToLocalStorage,loginRender } = toggleMenuReducer.actions;

export default toggleMenuReducer.reducer;
