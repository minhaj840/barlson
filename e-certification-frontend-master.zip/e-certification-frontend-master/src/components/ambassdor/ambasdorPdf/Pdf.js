import {
  Document,
  Image,
  Page,
  StyleSheet,
  Text,
  View,
} from "@react-pdf/renderer";
import React from "react";
import moment from "moment";

function AmbassdorPdf({ data }) {
  const issuesDate = moment(data?.data?.startDate).format("DD MMM YYYY");
  const originalDate = moment(data?.data?.startDate);
  const oneYearLater = originalDate.add(1, "years");
  const expiredOn = oneYearLater.format("DD MMM YYYY");

  const styles = StyleSheet.create({
    container: {
      margin: "20px auto",
      maxWidth: "290",
      backgroundColor: "black",

      position: "relative",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
    },
    imgContainer: {
      // width:"100%",
      // position: "absolute",
      // top: "23%",
      // // left: "30%",
      // textAlign: "center",
      // display: "flex",
      // justifyContent: "center",
      position: "absolute",
      top: "22.9%",
      textAlign: "center",
      width: "100%",
    },
    img: {
      width: 123,
      height: 123,
      objectFit: "cover",
      objectPosition: "center top",
      borderRadius: "50%",
      textAlign: "center",
      margin: "0 auto",
      display: "block",
    },
    imgContainer1: {
      position: "absolute",
      top: "52%",
      textAlign: "center",
      display: "flex",
      justifyContent: "center",
      width: "100%",
    },

    name: {
      fontSize: "22px",
      textTransform: "uppercase",
      color: "#03113f",
      fontWeight: 800,
      fontFamily: "Times-Bold",
      // fontFamily: "Akrobat",
    },
    imgContainer2: {
      position: "absolute",
      top: "60.4%",
      textAlign: "center",
      display: "flex",
      justifyContent: "center",
      width: "100%",
    },
    name2: {
      fontSize: "12px",
      color: "#ffba00",
      fontWeight: 800,
      // fontFamily: "Akrobat",
    },

    // 3
    imgContainer3: {
      position: "absolute",
      top: "67%",
      textAlign: "center",
      display: "flex",
      justifyContent: "center",
      width: "100%",
    },
    name3: {
      fontSize: "12px",
      color: "#2d2d2d",
      fontWeight: 800,
      fontFamily: "Times-Bold",

      // fontFamily: "Akrobat",
    },

    // 5
    imgContainer5: {
      position: "absolute",
      // top: "71%",
      top: "80%",
      textAlign: "center",
      display: "flex",
      justifyContent: "center",
      width: "100%",
      padding: "0 7%",
    },
    name5: {
      fontSize: "12px",
      color: "#2d2d2d",
      fontWeight: 800,
      lineHeight: 1.4,
      marginVertical: 0,
      fontFamily: "Times-Bold",

      // fontFamily: "Akrobat",
    },
    // 6
    imgContainer6: {
      position: "absolute",
      top: "89.2%",
      textAlign: "center",
      display: "flex",
      justifyContent: "center",
      width: "100%",
      padding: "0 3%",
    },
    name6: {
      fontSize: "12px",
      color: "#2d2d2d",
      fontWeight: 800,
      fontFamily: "Times-Bold",

      // fontFamily: "Akrobat",
    },
    imgContainer7: {
      position: "absolute",
      top: "-9%",
      textAlign: "center",
      display: "flex",
      justifyContent: "center",
      width: "100%",
    },

    // 8
    imgContainer8: {
      position: "absolute",
      // top: "80%",
      top: "71%",
      textAlign: "center",
      display: "flex",
      justifyContent: "center",
      width: "100%",
    },
    name8: {
      fontSize: "12px",
      color: "#2d2d2d",
      fontWeight: 800,
      fontFamily: "Times-Bold",

      // fontFamily: "Akrobat",
    },
    // 9
    imgContainer9: {
      position: "absolute",
      top: "75%",
      textAlign: "center",
      display: "flex",
      justifyContent: "center",
      width: "100%",
    },
    name9: {
      fontSize: "12px",
      color: "#2d2d2d",
      fontWeight: 800,
      fontFamily: "Times-Bold",

      // fontFamily: "Akrobat",
    },
    bold: {
      fontFamily: "Times-Bold",
    },
    logo: {
      margin: "0 auto",
      width: 200,
      height: 200,
      borderRadius: "50%",
    },
  });
  //<PDFViewer style={{ width: "100%" }} height={"400"}>

  return (
    <Document>
      <Page size="A4" style={{ backgroundColor: "black" }}>
        <View style={styles.container}>
          <View>
            <Image src="/card.png" alt="logo" />
          </View>

          <View style={styles.imgContainer7}>
            <Image src="/comp.png" alt="logo" style={styles.logo} />
          </View>
          <View style={styles.imgContainer}>
            <Image src={data?.data?.profile} alt="logo" style={styles.img} />
          </View>
          <View style={styles.imgContainer1}>
            <Text style={styles.name}>{data?.data?.name}</Text>
          </View>
          <View style={styles.imgContainer2}>
            <Text style={styles.name2}>Campus Ambassador</Text>
          </View>

          <View style={styles.imgContainer3}>
            <Text style={styles.name3}>Id Nu : {data?.data?.ID}</Text>
          </View>

          <View style={styles.imgContainer8}>
            <Text style={styles.name8}>Issued Date : {issuesDate}</Text>
          </View>

          <View style={styles.imgContainer9}>
            <Text style={styles.name9}>Expired On : {expiredOn}</Text>
          </View>

          <View style={styles.imgContainer5}>
            <Text style={styles.name5}>
              <Text style={styles.bold}>Collge Name</Text> :{" "}
              {data?.data?.collgeName}
            </Text>
          </View>

          <View style={styles.imgContainer6}>
            <Text style={styles.name6}>www.bqarlson.com</Text>
          </View>
        </View>
      </Page>
    </Document>
  );
}

export default AmbassdorPdf;
