import React, { memo, useState } from "react";
import { Axios, AxiosCyclic } from "../../services/axios";
import Loader from "../../utils/loader/Loader";
import {
  toastApiError,
  toastError,
  toastSuccess,
} from "../../utils/toast/toast";
import { Col, Row } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { toggleMenu } from "../../redux/globalApiSlice";

function Ambassdor() {
  const dispatch = useDispatch();

  const [credential, setCredential] = useState({
    name: "",
    email: "",
    collgeName: "",
    contact: ""
  });

  const [isLoading, setIsLoading] = useState(false);

  const handleOnchange = (e) => {
    const name = e.target.name;
    const value = e.target.value;

    setCredential({ ...credential, [name]: value });
  };

  const handleOnchangeImage = (e) => {
    const value = e.target.files[0];
    setCredential({ ...credential, profile: value });
  };

  // handle submit
  const handleRegisterAsAmbassdor = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    const { name, email, collgeName, profile, contact } = credential;

    const contactRegex = /^\d{10}$/;
    const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/

    const emailValid = emailRegex.test(email);;
    const contactValid = contactRegex.test(contact);

    try {
      if (!name || !email || !profile || !collgeName || !contact) {
        toastError("all fields are required!");
      }
      else if (!emailValid) {
        toastError("email must be a valid email")

      } else if (!contactValid) {
        toastError("contact must be a valid")
      }

      else {
        const resp = await AxiosCyclic.post("/ambassdor/register", credential, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });

        if (resp?.status === 201) {
          toastSuccess("student registered successfully");
          if (resp?.data) {
            dispatch(
              toggleMenu({
                open: true,
              })
            );
            // toggle menut btn
          }
        } else {
          toastError(resp?.data?.message);
        }
      }
    } catch (error) {
      toastApiError(error);
    } finally {
      // setCredential({
      //     name:"",
      //     email:"",
      //     collgeName:"",
      //     profile:""
      // })
      setIsLoading(false);
    }
  };

  return (
    <>
      <Loader loader={isLoading} />

      <div className="section wrapper">
        <div className="container">
          <Row className="justify-content-center ambassador loginStudent">
            <Col lg={7}>
              <div className="h-100 border rounded border-1 p-3">
                <div className="login">
                  <Loader />
                  <h4>Become Ambassdor 📢</h4>
                </div>
                <div class="mb-3">
                  <label class="form-label" for="textInput">
                    Enter your full name *
                  </label>
                  <input
                    type="text"
                    id="textInput"
                    class="form-control"
                    placeholder="Enter your full name"
                    name="name"
                    value={credential.name}
                    onChange={(e) => handleOnchange(e)}
                  />
                </div>
                <div class="mb-3">
                  <label class="form-label" for="textInput">
                    Registered email*
                  </label>
                  <input
                    type="email"
                    id="textInput"
                    class="form-control"
                    placeholder="Enter registered email"
                    name="email"
                    value={credential.email}
                    onChange={(e) => handleOnchange(e)}
                  />
                </div>
                <div class="mb-3">
                  <label class="form-label" for="textInput">
                    Enter mobile number*
                  </label>
                  <input
                    type="number"
                    id="textInput"
                    class="form-control"
                    placeholder="Enter mobile number"
                    name="contact"
                    value={credential.contact}
                    onChange={(e) => handleOnchange(e)}
                    required={true}
                  />
                </div>
                <div class="mb-3">
                  <label class="form-label" for="textInput">
                    Enter your college name *
                  </label>
                  <input
                    type="text"
                    id="textInput"
                    class="form-control"
                    placeholder="Enter your college name"
                    name="collgeName"
                    value={credential.collgeName}
                    onChange={(e) => handleOnchange(e)}
                  />
                </div>
                <div class="mb-3">
                  <label class="form-label" for="textInput">
                    Image *
                  </label>
                  <input
                    type="file"
                    id="textInput"
                    class="form-control"
                    placeholder="Enter your college name"
                    name="profile"
                    onInput={(e) => handleOnchangeImage(e)}
                  />
                </div>

                <div className="mt-3 d-flex ">
                  <button
                    className="btn btn-primary"
                    type="submit"
                    onClick={(e) => handleRegisterAsAmbassdor(e)}
                    disabled={isLoading}
                  >
                    Become Ambassdor
                  </button>
                  <div className="mx-4 d-flex gap-2 align-items-center">
                    <span>Already Registerd</span>
                    <button
                      className="mx-1 btn btn-success"
                      type="submit"
                      onClick={() =>
                        dispatch(
                          toggleMenu({
                            open: true,
                          })
                        )
                      }
                    >
                      Login
                    </button>
                  </div>
                </div>
              </div>
            </Col>
          </Row>
        </div>
      </div>
    </>
  );
}

export default memo(Ambassdor);
