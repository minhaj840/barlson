import { useEffect, useState } from "react";
import Offcanvas from "react-bootstrap/Offcanvas";
import Loader from "../../utils/loader/Loader";
import {
  toastApiError,
  toastError,
  toastSuccess,
} from "../../utils/toast/toast";
import { Axios } from "../../services/axios";
import {
  loginRender,
  saveToLocalStorage,
  toggleMenu,
} from "../../redux/globalApiSlice";
import { useDispatch, useSelector } from "react-redux";
import AmbassdorPdf from "./ambasdorPdf/Pdf";
import PdfViewModel from "./ambasdorPdf/PdfViewModel";
import { PDFViewer } from "@react-pdf/renderer";
import { AmbassadorStatusProfile } from "../../services/ambassdor/ambassdor";
import { useQuery } from "react-query";
import { ambassadorId, logoutAmabassador } from "../../utils/profileID";

function Menu({ show, handleClose }) {
  const dispatch = useDispatch();
  const [ren, setRen] = useState(Math.random());
  const [credential, setCredential] = useState("");
  const render = useSelector((state) => state?.toggleMenu?.render);
  const [data1, setData1] = useState([]);
  const [show1, setShow1] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // handle submit
  const loginStudentAsambasdor = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      if (!credential) {
        toastError("email is required!");
      } else {
        // do signin
        const resp = await Axios.post("/ambassdor/login", {
          email: credential,
        });

        if (resp?.status === 201) {
          if (resp?.data) {
            toastSuccess("student Login successfully");
            setRen(Math.random());
            window.location.reload();
            dispatch(
              saveToLocalStorage({
                data: resp?.data?.data,
              })
            );

         

            dispatch(loginRender());
          } else {
            toastError("something error occured!");
          }
        } else {
          toastError(resp?.data?.message);
        }
      }
    } catch (error) {
      toastApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose1 = () => {
    setShow1(false);
  };
  const handleShow1 = () => setShow1(true);

  const {
    data,
    isLoading: isLoad,
    error,
    isError,
    isSuccess,
  } = useQuery(
    ["", ambassadorId],
    () => ambassadorId !== null && AmbassadorStatusProfile(ambassadorId)
  );

  if (isError) {
    toastApiError(error);
  }

  useEffect(() => {

    const jsonData = JSON.parse(localStorage.getItem("IdCard"));
    console.log(jsonData);
    setData1(jsonData);
 
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [render, ren]);
  return (
    <>
      <PdfViewModel show={show1} handleClose={handleClose1} data={data?.data} />
      <Offcanvas show={show} onHide={handleClose} backdrop={true}>
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>
            <span
              className="fw-bold text-primary fs-4"
              style={{ display: "block", borderBottom: "5px solid red" }}
            >
              Ambassdor Student Login
            </span>
          </Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <Loader loader={isLoading || isLoad} />
          {!data1?.data && (
            <form
              className="h-auto border rounded border-1 p-3"
              onSubmit={loginStudentAsambasdor}
            >
              <div className="login">
                <Loader />
                <h4>Login Ambassdor 📪</h4>
              </div>

              <div class="mb-3">
                <label class="form-label" for="textInput">
                  Registered email*
                </label>
                <input
                  type="text"
                  id="textInput"
                  class="form-control"
                  placeholder="Enter registered email"
                  onChange={(e) => setCredential(e.target.value)}
                />
              </div>

              <div className="mt-3">
                <button
                  className="btn btn-outline-success"
                  type="submit"
                  disabled={isLoading}
                >
                  Login Ambassdor
                </button>
              </div>
            </form>
          )}

          <div className="span my-2">
            <span className="text-black fw-bold fs-6">Your ID Card </span>
          </div>

          {!data?.data?.data?.isIssued && (
            <div className="span my-2">
              <span className="text-black fw-bold fs-6">Not Issues Yet! </span>
            </div>
          )}

          {data?.data?.data ? (
            <div className="my-2">
              {isSuccess && data?.data?.data?.isIssued && (
                <>
                  <PDFViewer style={{ width: "100%" }} height={400}>
                    <AmbassdorPdf data={data?.data} key={ren} />
                  </PDFViewer>

                  <button
                    className="btn mt-3 btn-primary btn-sm"
                    onClick={() => handleShow1()}
                  >
                    Print ID CARD
                  </button>
                </>
              )}
            </div>
          ) : (
            <div className="span my-2">
              <span className="text-black fw-bold fs-6">
                No ID Card.if admin issues then show below.
              </span>
            </div>
          )}

          {data1?.data && (
            <button
              className="btn btn-danger btn-sm"
              onClick={() => {
                logoutAmabassador();
                dispatch(loginRender());

        
              }}
            >
              Logout
            </button>
          )}
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
}

export default Menu;
