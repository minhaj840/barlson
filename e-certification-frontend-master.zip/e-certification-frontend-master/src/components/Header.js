import React, { memo, useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import { isAutheticated } from "../utils/isAuth";
import Menu from "./ambassdor/Menu";
import { useDispatch, useSelector } from "react-redux";
import { toggleMenu } from "../redux/globalApiSlice";
import { ambassadorId } from "../utils/profileID";
import { FcMenu } from "react-icons/fc";

function Header() {
  const dispatch = useDispatch();
  const render = useSelector((state) => state?.toggleMenu?.render);
  const open = useSelector((state) => state?.toggleMenu?.open);
  const [show, setShow] = useState(open);

  const handleClose = () => {
    setShow(false);
    dispatch(
      toggleMenu({
        open: false,
      })
    );
  };
  const handleShow = () => setShow(true);

  const { token } = isAutheticated();

  useEffect(() => {
    if (open) {
      handleShow();
    }
  }, [open]);
  useEffect(() => {
    // render page
  }, [render]);
  // BQARLSON CERTIFICATE
  return (
    <>
      <Menu show={show} handleClose={() => handleClose()} key={render} />
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark  w-100 fixed-top">
        <div className="container">
          <NavLink className="navbar-brand" to="/">
            <img
              src={"/logo11.png"}
              alt="logo"
              style={{
                display: "block",
                objectFit: "cover",
                width: 200,
              }}
            />
          </NavLink>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon">
              <FcMenu size={25} />
            </span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <NavLink className="nav-link" to="/">
                  Home
                </NavLink>
              </li>
              {token && (
                <li className="nav-item">
                  <NavLink className="nav-link" to="/student/profile">
                    Profile
                  </NavLink>
                </li>
              )}
            </ul>
            <div className="d-flex gap-3">
              {!token && (
                <div>
                  <NavLink to="/login">
                    <button className="btn btn-danger" type="submit">
                      Intern Login
                    </button>
                  </NavLink>
                </div>
              )}

              {/*    <NavLink to="/ambassdor">
                <button className=" btn btn-info" type="submit">
                  Become Ambassdor
                </button>
              </NavLink> */}

              {/**  <NavLink to="/hackthon/student">
                <button className=" btn btn-success" type="submit">
                  Hackthon Test
                </button>
              </NavLink> */}

              <NavLink to="/certification">
                <button className=" btn btn-success" type="submit">
                  Hackthon Certificate
                </button>
              </NavLink>
              {ambassadorId !== null && (
                <button
                  className=" btn btn-warning"
                  type="submit"
                  onClick={() => handleShow()}
                >
                  Download your ID CARD
                </button>
              )}

              {/* <NavLink to="/student/register">
              <button className="btn btn-danger" type="submit">
                Admin Login
              </button>
            </NavLink> */}
            </div>
          </div>
        </div>
      </nav>
    </>
  );
}

export default memo(Header);
