import React, { memo } from "react";
import { Modal } from "react-bootstrap";
import { PDFViewer } from "@react-pdf/renderer";
import InternIdCard from "./InternIdCard";

function InternCardModel({ show, handleClose, data }) {


  return (
    <>
      <Modal
        show={show}
        animation={true}
        size={"lg"}
        centered
        onHide={handleClose}
      >
        <Modal.Header closeButton>
          <Modal.Title>ID CARD VIEWER</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <PDFViewer style={{ width: "100%" }} height={800}>
            <InternIdCard data={data||[]}/>
          </PDFViewer>
        </Modal.Body>
        <Modal.Footer></Modal.Footer>
      </Modal>
    </>
  );
}

export default memo(InternCardModel);
