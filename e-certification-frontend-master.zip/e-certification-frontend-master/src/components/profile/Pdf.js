import React, {memo, useState } from "react";
import {
  Document,
  Page,
  Text,
  View,
  Image,
  StyleSheet,
  Font,
} from "@react-pdf/renderer";
import { PDFViewer } from "@react-pdf/renderer";
import { randomID } from "../../utils/randId";
import QRCode from "qrcode";

// const source = "https://fonts.googleapis.com/css2?family=Satisfy&display=swap";

// Font.register({ family: "Satisfy", src: source });

const styles = StyleSheet.create({
  Page: {
    width: 1000,
    height: 1000,
  },

  container: {
    width: "100%",
    height: "100%",
    overflow: "hidden",
    border: "2px dashed black",
    fontFamily: "Helvetica-Bold",
  },

  header: {
    display: "flex",
    justifyContent: "space-evenly",
    alignItems: "center",
    width: "100%",
    // height:"300px",
    flexDirection: "row",
    // backgroundColor:"red",
    position: "relative",
  },
  imgContainer: {
    flex: 0.3,
    height: "200px",
    //  backgroundColor:"blue",
  },
  img: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
  },
  title: {
    flex: 0.6,
    display: "flex",
    alignItems: "center",
    flexDirection: "column",
    textAlign: "center",
    lineHeight: "1.2px",
    padding: "2px 8px",
  },
  text: {
    fontWeight: 800,
    fontSize: "24px",
    letterSpacing: "0.8px",
    padding: "5px 20px",
    // fontWeight: "bold",
  },
  textCertificate: {
    fontSize: "25px",
    letterSpacing: "0.8px",
    fontWeight: 700,
  },
  regnoContainer: {
    flex: 0.3,
    bottom: "100px",
    padding: "10px",
    // backgroundColor:"green"
  },

  section2: {
    textAlign: "center",
    padding: " 20px 20px",
    // backgroundColor:"blue"
  },
  text2Conatiner: {
    fontWeight: "600px",
    fontSize: "18px",
    letterSpacing: "0.8px",
    lineHeight: "1.4px",
    padding: "5px",
  },
  section3: {
    display: "flex",
    height: "300px",
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    padding: "20px",
    // backgroundColor:"red"
  },
  section3img: {
    width: "160px",
    height: "160px",
    objectFit: "cover",
  },
  Section3box1: {
    flex: 0.4,
    textAlign: "center",
    padding: "13px",
    // padding:"4px 10px"
    // backgroundColor:"blue",
  },
  box1Text1: {
    fontSize: "15px",
    padding: "4px",
    //  borderBottom:"2px solid yellow"
  },
  box1Text2: {
    fontSize: "13px",
    padding: "4px",
  },
  box1Text3: {
    fontSize: "15px",
    padding: "4px",
    // borderBottom:"2px solid yellow"
  },
  box1Text4: {
    fontSize: "13px",
    padding: "4px",
  },

  Section3box2: {
    flex: 0.5,
    justifyContent: "center",
    textAlign: "center",

    padding: "10px",
    // backgroundColor:"red"
  },
  Section3box3: {
    flex: 0.4,
    textAlign: "center",
    padding: " 5px 30px",
    // backgroundColor:"blue"
  },
  box2Text1: {
    fontSize: "14px",
    padding: "4px",
    // borderBottom:"2px solid yellow"
  },
  box2Text2: {
    fontSize: "13px",
    padding: "4px",
  },
  box2Text3: {
    fontSize: "15px",
    padding: "4px",
    // borderBottom:"2px solid yellow"
  },
  box2Text4: {
    fontSize: "13px",
    padding: "4px",
  },

  section4: {
    padding: "10px",
    textAlign: "center",
  },
  section4Text: {
    fontSize: "15px",
    padding: "5px",
    lineHeight: "1.4px",
    fontWeight: "500",
  },
  section5: {
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "center",
    padding: "10px 30px",
    // backgroundColor:"red",

    marginTop: "30px",
  },
  section5Box1: {
    flex: 0.3,
    textAlign: "center",
    //  backgroundColor:"blue",
    padding: "10px",
  },
  section5Box2: {
    flex: 0.6,
    display: "flex",
    alignItems: "center",

    // backgroundColor:"green",
    padding: "10px",
  },
  section5Box3: {
    flex: 0.3,
    textAlign: "center",
    justifyContent: "center",
    display: "flex",
    //  backgroundColor:"yellow",
    padding: "10px",
  },
  section5Box2Img: {
    // width:"60px",
    // height:'60px',
    width: "100px",
    height: "100px",
    objectFit: "cover",
    textAlign: "center",
  },
  section5Box1Text1: {
    // fontSize: "15px",
    // fontWeight: 600,
    // padding: "5px",
    // fontFamily: "Times-Italic",
  },
  section5Box2Text2: {
    fontSize: "13px",
    fontWeight: 300,
    padding: "5px",
  },
  section6: {
    top: "6px",
    padding: "20px",
    textAlign: "center",
    width: "80%",
    margin: "auto",
    // backgroundColor:"red"
  },
  space: {
    marginTop: "10px",
  },
  section6Text: {
    fontSize: "15px",
    fontWeight: 500,
    padding: "8px",
  },
  line: {
    width: "50%",
    height: "2px",
    backgroundColor: "yellow",
    textAlign: "center",
    margin: "0px auto",
  },
  Headerimg: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
    padding: " 10px",
  },
  HeaderimgConainer: {
    width: "120px",
    height: "120px",
    top: "3px",
    right: "15px",
    transform: "rotate(180deg)",
  },
  FooterimgConainer: {
    position: "absolute",
    display: "flex",
    width: "120px",
    height: "120px",
    bottom: "-13px",
    right: "-13px",
  },
  Footerimg: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
    padding: " 10px",
  },
});

function PdfDownloadDemo({ info }) {
  const [qrcode, setQrCode] = useState("");

  const qrData = {
    name: info.name,
    role: info.internRole,
    duration: info.duration,
  };
  QRCode.toDataURL(JSON.stringify(qrData)).then((data) => {
    setQrCode(data);
  });
  const RegId = randomID(6);

  return (
    <PDFViewer style={{ width: "85vw", height: "100vh" }}>
      <Document>
        <Page style={styles.Page} size="A4">
          <View style={styles.container}>
            {/* start of header  */}
            <View style={styles.HeaderimgConainer}>
              <Image
                style={styles.Headerimg}
                src="https://res.cloudinary.com/dycuwk9fb/image/upload/v1694345103/xic9dlsovuda7ezieflx.png"
                alt=""
              ></Image>
            </View>
            <View style={styles.header}>
              <View style={styles.imgContainer}>
                <Image
                  style={styles.img}
                  src="https://res.cloudinary.com/dycuwk9fb/image/upload/v1694344856/uphgapcelz8vdq2ffvnn.png"
                  alt=""
                />
              </View>
              <View style={styles.title}>
                <Text style={styles.textCertificate}>
                  C E R T I F I C A T E
                </Text>
                <Text style={styles.text}>OF</Text>
                <Text style={styles.text}>COMPLETETION</Text>
                <Text style={styles.text}>Congratulation!</Text>
              </View>
              <View style={styles.regnoContainer}>
                <Text>Reg.No. {RegId}</Text>
              </View>
            </View>
            {/* end of header  */}

            {/* section2 start */}
            <View style={styles.section2}>
              <Text style={styles.text2Conatiner}>
                This certificate is proudly presented in recognition of the
                completion of Intership at E-WEBSITE PROVIDER PVT. LTD.
              </Text>
            </View>
            {/* section 2 end  */}
            {/* section 3 start */}
            <View style={styles.section3}>
              <View style={styles.Section3box1}>
                <Text style={styles.box1Text1}>{info?.name}</Text>
                <View style={[styles.line]}></View>
                <Text style={styles.box1Text2}>Name</Text>

                <Text style={styles.space}></Text>

                <Text style={styles.box1Text3}>{info?.startDate}</Text>
                <View style={styles.line}></View>
                <Text style={styles.box1Text4}>Start Date</Text>
              </View>
              <View style={styles.Section3box2}>
                <Image
                  style={styles.section3img}
                  src="https://res.cloudinary.com/dycuwk9fb/image/upload/v1694344926/qoeb4fmrivgyv98r4n3l.png"
                  alt=""
                />
              </View>
              <View style={styles.Section3box3}>
                <Text style={styles.box2Text1}>{info?.internRole}</Text>
                <View style={[styles.line]}></View>
                <Text style={styles.box2Text2}>Role</Text>

                <Text style={styles.space}></Text>
                <Text style={styles.box2Text3}>{info?.endDate}</Text>
                <View style={styles.line}></View>
                <Text style={styles.box2Text4}>End Date</Text>
              </View>
            </View>

            {/* end of section 3 */}
            {/* start of section 4 */}

            <View style={styles.section4}>
              <Text style={styles.section4Text}>
                His/her association with us was very fruitful and we wish
                him/her all the best in the future endeavours.
              </Text>
            </View>

            {/* end of section 4 */}

            {/* strat of section 5 */}
            <View style={styles.section5}>
              <View style={styles.section5Box1}>
                <View style={styles.ashifSign}>
                  <Image style={styles.ashifSign1} src="/ashifUl.png" />
                </View>
                <View style={styles.line}></View>
                <Text style={styles.section5Box2Text2}>Director</Text>
              </View>
              <View style={styles.section5Box2}>
                <Image style={styles.section5Box2Img} src={qrcode} />
              </View>
              <View style={styles.section5Box3}>
                <View style={styles.ashifSign}>
                  <Image style={styles.ashifSign1} src="/ashif.png" />
                </View>
                <View style={styles.line}></View>
                <Text style={styles.section5Box2Text2}>Manager</Text>
              </View>
            </View>
            {/* end of section 5  */}

            {/* start of section 6  */}
            <View style={styles.section6}>
              <Text style={styles.section6Text}>www.ewebsiteprovider.com</Text>
              <Text style={styles.section6Text}>
                First step towards taking your business online.
              </Text>
            </View>
            <View style={styles.FooterimgConainer}>
              <Image
                style={styles.Footerimg}
                src="https://res.cloudinary.com/dycuwk9fb/image/upload/v1694345103/xic9dlsovuda7ezieflx.png"
                alt=""
              ></Image>
            </View>
          </View>
        </Page>
      </Document>
    </PDFViewer>
  );
}

export default memo(PdfDownloadDemo);
