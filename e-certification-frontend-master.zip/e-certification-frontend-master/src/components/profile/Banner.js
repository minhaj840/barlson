import React, { memo, useCallback, useEffect, useState } from "react";

import { signout } from "../../utils/isAuth";
import moment from "moment";
import Avatar from "react-avatar";
import { getStudentProfile } from "../../services/dashboad/dash";
import { useQuery } from "react-query";
import { studentID } from "../../utils/profileID";
import { toastApiError } from "../../utils/toast/toast";
import Loader from "../../utils/loader/Loader";
import PdfDownloadDemo from "./Pdf";
import InternCardModel from "./InternCardModel";

function Banner(props) {
  const [date, setDate] = useState({
    startDate: "",
    endDate: "",
  });
  const [show, setShow] = useState(false)

  const [info, setInfo] = useState({
    name: "",
    email: "",
    internRole: "",
    duration: "",
    certificate: "",
    isCourseCompleted: false,
  });

  const { data, isLoading, error, isError, isSuccess } = useQuery(
    ["student", studentID],
    () => getStudentProfile(studentID)
  );

  if (isError) {
    toastApiError(error);
  }

  useEffect(() => {
    if (isSuccess) {
      const {
        name,
        email,
        internRole,
        duration,
        startDate,
        studentID,
        isCourseCompleted,
        certificate,
      } = data?.data?.data;

      const date = moment(startDate);
      const formattedStartDate = date.format("DD MMM YYYY");

      // get end date
      const formatedStartDateCal = moment(startDate);
      const match = duration.match(/\d+/);
      const durationMonths = parseInt(match[0], 10);
      const FendDate = formatedStartDateCal
        .clone()
        .add(durationMonths, "months");
      const formattedEndDate = FendDate.format("DD MMM YYYY");

      setDate({
        startDate: formattedStartDate,
        endDate: formattedEndDate,
      });

      setInfo({
        name: name,
        email: email,
        internRole: internRole,
        duration: duration,
        studentID: studentID,
        isCourseCompleted: isCourseCompleted,
        certificate: certificate,
        startDate: formattedStartDate,
        endDate: formattedEndDate,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSuccess]);


    // handle close
    const handleClose = () => {
      setShow(false)
  }
    const handleOpen = useCallback(() => {
      setShow(true)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[show])


  return (
    <>
      <Loader loader={isLoading} />
      {
        show && <InternCardModel show={show} handleClose={handleClose} data={info} />
      }
      <div className="bannerTopImg">
        <div className="row align-items-center flex-wrap">
          <div className="col-xl-12 col-lg-12  col-md-12 md:flex-wrap sm:flex-wrap col-lg-12">
            <div className="pt-16 rounded-top-md banner"></div>
            <div className=" row1 d-flex  align-items-end justify-content-between bg-white px-4 pt-2 pb-4 rounded-none rounded-bottom-md shadow-sm">
              <div className="d-flex gap-5 sm:d-block sm:gap-4">
                <div className="row position-relative  align-items-end mt-n5">
                  <Avatar
                    name={info?.name}
                    size="260"
                    className="avatar-xl rounded-circle border border-4 border-white"
                  />
                </div>
                <div className="sm:col-12 lh-1">
                  <h2 className="mb-0">{info?.name}</h2>

                  <p className="mt-3 d-block fw-bold ">
                    StudentID : <span>{info?.studentID}</span>
                  </p>
                  <p className="mt-3 d-block fw-bold ">
                    Email : <span>{info?.email}</span>
                  </p>

                  <p className="mt-1 d-block fw-bold ">
                    Role: <span>{info?.internRole}</span>
                  </p>
                  <p className="mt-1 d-block fw-bold ">
                    Duration : <span>{info?.duration}</span>
                  </p>
                  <p className="mt-1 d-block fw-bold ">
                    StartDate:{" "}
                    <span className="text-success">{date.startDate}</span>
                  </p>
                  <p className="mt-1 d-block fw-bold ">
                    EndDate:{" "}
                    <span className="text-success">{date.endDate}</span>
                  </p>
                </div>
              </div>

              <div className="d-flex align-items-center gap-4">
                {/*   {info?.isCourseCompleted && (
            
                <button
                  className="btn btn-primary btn-sm"
                  id="download_pdf"

                >
                  Download certificate
                </button>
          )} */}

                <button
                  className="btn btn-danger btn-sm mx-2"
                  onClick={() => signout()}
                >
                  Logout
                </button>
                <button
                  className="btn btn-info btn-sm mx-2"
                  onClick={()=>handleOpen()}
                >
                  Download your ID cards
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="row ">
          <div className="col-xl-121 col-lg-12 col-md-12 col-12">
            {info?.isCourseCompleted ? (
              // eslint-disable-next-line jsx-a11y/alt-text
              <PdfDownloadDemo info={info} />
            ) : (
              <div className="py-3">
                <h5>Not issues certificate yet. Please check back later.</h5>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default memo(Banner);

/*   <object
                width="100%"
                height="800"
                data={info?.certificate}
                type="application/pdf"
              /> */
