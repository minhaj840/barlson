import React, { useEffect } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { signoutAdmin } from "../utils/isAuth";

function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  // useEffect(() => {
  //   navigate("/student/register/");
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [location.pathname === "/student/register/all"]);

  return (
    <div
      className="border-top  d-flex flex-column flex-shrink-0  text-white bg-dark"
      style={{
        width: "290px",
        height: "100vh",
        overflow: "auto",
        paddingLeft: "1em",
        paddingTop: "4em",
      }}
    >
      <ul className="nav nav-pills w-100 flex-column bg-dark h-100 mb-auto">
        <li className="nav-item sideBarLink ">
          <NavLink to="/student/register/" className="nav-link text-white">
            Register Student
          </NavLink>
        </li>

        <li className="nav-item sideBarLink ">
          <NavLink
            to="/student/register/allStudent"
            className="nav-link text-white"
          >
            All Students
          </NavLink>
        </li>

        <li className="nav-item sideBarLink ">
          <NavLink
            to="/student/register/campus"
            className="nav-link text-white"
          >
            Campus Ambassador
          </NavLink>
        </li>
        <li className="nav-item sideBarLink ">
          <NavLink to="/student/register/csv" className="nav-link text-white">
            hackthon Certificate
          </NavLink>
        </li>

        <li className="nav-item sideBarLink ">
          <NavLink
            to="/student/register/hackthon_question"
            className="nav-link text-white"
          >
            Question + Student -(CSV)
          </NavLink>
        </li>

        <li className="nav-item sideBarLink ">
          <NavLink
            to="/student/register/hackthon_solution"
            className="nav-link text-white"
          >
            Hackthon Answer
          </NavLink>
        </li>

        <li className="nav-item d-none sideBarLink ">
          <NavLink
            to="/student/register/offerLetter"
            className="nav-link text-white"
          >
            Offer Letter
          </NavLink>
        </li>
        <li className="nav-item1 sideBarLink ">
          <NavLink
            to="/student/register/poster"
            className="nav-link text-white"
          >
            Poster & Social Media
          </NavLink>
        </li>

        <li className="nav-item sideBarLink ">
          <NavLink to="/student/register/email" className="nav-link text-white">
            Email Sender
          </NavLink>
        </li>

        <li className="nav-item sideBarLink ">
          <NavLink to="/student/register/doc" className="nav-link text-white">
            Apply Internship Doc
          </NavLink>
        </li>
      </ul>
      <hr />
      <div className="dropdown">
        <NavLink
          to="#"
          className="d-flex align-items-center text-white text-decoration-none dropdown-toggle"
          id="dropdownUser1"
          data-bs-toggle="dropdown"
          aria-expanded="false"
        >
          <img
            src="https://github.com/mdo.png"
            alt=""
            width="32"
            height="32"
            className="rounded-circle me-2"
          />
          <strong>Md Ashif Reza</strong>
        </NavLink>
        <ul
          className="dropdown-menu dropdown-menu-dark text-small shadow"
          aria-labelledby="dropdownUser1"
        >
          <li>
            <a
              className="dropdown-item"
              href="#1"
              onClick={() => signoutAdmin()}
            >
              Sign out
            </a>
          </li>
        </ul>
      </div>
    </div>
  );
}

export default Sidebar;
