import React, { Suspense, lazy, memo, useEffect, useState } from "react";
import { Routes, Route, useLocation, useNavigate } from "react-router-dom";
import Notfound from "../NotFound";
import { isHackthonAutheticated } from "../../utils/isAuth";
import Loading from "../Loading";
import Timer from "./Test/Timer";
import { useQuery } from "react-query";
import { getStatusTest } from "../../services/hackTest/hackTest";
import { toastApiError } from "../../utils/toast/toast";
import Alert from "react-bootstrap/Alert";

// import LoginStudent from "./model/LoginStudent";
const LoginStudent = lazy(() => import("./model/LoginStudent"));
const RuleRegulation = lazy(() => import("./Test/RuleRegulation"));
const Questions = lazy(() => import("./Test/Questions"));
const Submit = lazy(() => import("./Test/Submit"));

function HackthonPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { token } = isHackthonAutheticated();
  const [show, setShow] = useState(true);
  const [newTime, setNewTime] = useState();

  const { isError, error, data, isSuccess } = useQuery("test1", getStatusTest);

  // model
  const handleClose = () => {
    setShow(false);
  };

  // add lazy loading
  useEffect(() => {
    // check completed test
    if (data?.data?.is_completed_test === true) {
      navigate("/hackthon/student/completed");
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname, isSuccess]);

  if (isError) {
    toastApiError(error);
  }

  const setTime = (obj) => {
    setNewTime(obj);
  };

  // create case for showing alert

  return (
    <>
      {!token && (
        <>
          <LoginStudent show={show} handleClose={handleClose} />
          <Notfound />
        </>
      )}

      {token && (
        <div>
          {/*
      {newTime?.time < 9 && newTime?.date === "28 Oct 2023" && (
        <Alert variant="warning" className="mt-5" dismissible>
          <Alert.Heading>Please Refresh page</Alert.Heading>
          <p>Your test will start from 10:00 AM on 28 Oct 2023</p>
        </Alert>
      )}

      {newTime?.date !== "28 Oct 2023" && (
        <Alert variant="warning" className="mt-5" dismissible>
          <Alert.Heading>Please Refresh page</Alert.Heading>
          <p>Your test will start from 10:00 AM on 28 Oct 2023</p>
        </Alert>
      )}
      */}

          <div className="profile-section">
            {location.pathname !== "/hackthon/student/completed" && <Timer />}
          </div>

          <Routes>
            <Route
              path="/"
              element={
                <Suspense fallback={<Loading />}>
                  <RuleRegulation />
                </Suspense>
              }
            />
            <Route
              path="/start"
              element={
                <Suspense fallback={<Loading />}>
                  <Questions />
                </Suspense>
              }
            />
            <Route
              path="/completed"
              element={
                <Suspense fallback={<Loading />}>
                  <Submit />
                </Suspense>
              }
            />
          </Routes>
        </div>
      )}
    </>
  );
}

export default memo(HackthonPage);
