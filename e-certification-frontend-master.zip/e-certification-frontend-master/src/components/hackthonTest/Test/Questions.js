import React, { useEffect, useState } from "react";
import { Stepper } from "react-form-stepper";
import { useNavigate } from "react-router-dom";
import {
  getQuestion,
  submitAnswerToDb,
  submitTestTime,
} from "../../../services/hackTest/hackTest";
import { useMutation, useQuery } from "react-query";
import {
  toastApiError,
  toastError,
  toastSuccess,
} from "../../../utils/toast/toast";
import Loader from "../../../utils/loader/Loader";

function Questions() {
  const navigate = useNavigate();
  const [activeStep, setActiveStep] = useState(0);

  // get questions
  // getQuestion
  const mutationSub = useMutation(() => submitTestTime());

  const { isLoading, isError, error, data } = useQuery("test", getQuestion);
  const mutation = useMutation((answer) => submitAnswerToDb(answer));

  function Question1({ index }) {
    const [answer, setAnswer] = useState({
      website: "",
      github: "",
      questionId: data?.data?.data?.question[index]?._id,
    });
    const handleChangetext = (e) => {
      const name = e.target.name;
      const value = e.target.value;
      setAnswer({ ...answer, [name]: value });
    };

    // aubmitted
    const handleSubmitAnswer = () => {
      try {
        const { website, github } = answer;

        if (!website || !github) {
          toastError("Please enter a website or github or drive url");
        } else {
          // mutate
          mutation.mutate(answer);
          setActiveStep((activeStep) => activeStep + 1);
        }
      } catch (error) {
        toastApiError(error);
      }
    };

    useEffect(() => {
      if (mutation.isSuccess) {
        toastSuccess("answer submitted successfully");
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [mutation.isSuccess]);

    return (
      <div className="qus" key={data?.data?.data?.question[index]?._id}>
        <h3>{data?.data?.data?.question[index]?.title}</h3>
        <div className="my-2">
          <div
            dangerouslySetInnerHTML={{
              __html: data?.data?.data?.question[index]?.description,
            }}
          />
        </div>

        <div className="mt-2">
          <div class="mb-3">
            <label class="form-label" for="textInput">
              Enter deployed url - if question is from development otherwise add
              github url:
            </label>
            <input
              type="text"
              id="textInput"
              class="form-control"
              placeholder="deployed url"
              name="website"
              value={answer.website}
              onChange={(e) => handleChangetext(e)}
            />
          </div>
          <div class="mb-3">
            <label class="form-label" for="textInput">
              Enter Github code link or make zip of code add in drive.paste url
            </label>
            <input
              type="text"
              id="textInput"
              class="form-control"
              placeholder="github or drive url"
              name="github"
              value={answer.github}
              onChange={(e) => handleChangetext(e)}
            />
          </div>
          <div className="mb-2 ">
            <button
              className="btn btn-success"
              onClick={() => handleSubmitAnswer()}
            >
              Submut
            </button>
          </div>
        </div>
      </div>
    );
  }

  function Confirmation() {
    return (
      <div className="submitOage">
        <h4>If You have completed your test</h4>
        <button
          className="btn btn-success my-2"
          onClick={() => {
            mutationSub.mutate();
            window.location.reload();
          }}
        >
          submit test
        </button>
      </div>
    );
  }

  const steps = [
    { label: "Question 1" },
    { label: "Question 2" },
    { label: "Question 3" },
    { label: "Question 4" },
    { label: "Submit" },
  ];

  function getSectionComponent() {
    switch (activeStep) {
      case 0:
        return <Question1 index={0} />;
      case 1:
        return <Question1 index={1} />;
      case 2:
        return <Question1 index={2} />;
      case 3:
        return <Question1 index={3} />;
      case 4:
        return <Confirmation />;
      default:
        return null;
    }
  }

  // handle handleNavigate
  const handleNavigate = () => {
    mutationSub.mutate();
    window.location.reload();
  };

  if (isError) {
    toastApiError(error);
  }
  if (mutationSub.isError) {
    toastApiError(mutationSub.error);
  }
  useEffect(() => {
    if (mutationSub.isSuccess) {
      window.location.reload();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mutationSub.isSuccess]);

  return (
    <>
      <Loader loader={isLoading || mutation.isLoading} />

      <div className="mt-3 ">
        <div
          className="container d-flex justify-content-between align-items-center"
          style={{ padding: "20px" }}
        >
          {activeStep !== 0 && activeStep !== steps.length - 1 && (
            <button
              className="btn btn-primary"
              onClick={() => setActiveStep(activeStep - 1)}
            >
              Previous
            </button>
          )}
          {activeStep !== steps.length - 1 && (
            <button
              className="mx-3 btn btn-secondary"
              onClick={() => setActiveStep(activeStep + 1)}
            >
              Next
            </button>
          )}
          {activeStep === steps.length - 1 && (
            <>
              <button
                className="mx-3 btn btn-primary"
                onClick={() => setActiveStep(activeStep - 1)}
              >
                Previous
              </button>
              <button
                className="mx-3 btn btn-success"
                onClick={() => handleNavigate()}
              >
                Submit
              </button>
            </>
          )}
        </div>
        <hr />

        <div>
          <Stepper steps={steps} activeStep={activeStep} />

          <div className="container">{getSectionComponent()}</div>
        </div>
      </div>
    </>
  );
}

export default Questions;
