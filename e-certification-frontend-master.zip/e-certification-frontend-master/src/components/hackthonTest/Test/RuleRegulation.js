import React, { useEffect, useState } from "react";
import { getGuideLine } from "../../../services/hackTest/hackTest";
import { useQuery } from "react-query";
import Loader from "../../../utils/loader/Loader";
import { toastApiError } from "../../../utils/toast/toast";
function RuleRegulation() {
  const [guide, setGuide] = useState("");

  const { isLoading, isSuccess, isError, error, data } = useQuery(
    "guideline",
    getGuideLine
  );

  if (isError) {
    toastApiError(error);
  }

  useEffect(() => {
    if (isSuccess) {
      setGuide(data?.data?.data?.description);
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSuccess]);

  return (
    <>
      <Loader loader={isLoading} />
      <div className=" container shadow-1 p-1">
        <div className="my-2 rules d-flex justify-content-between">
          <span>
            <h1>Rule & Regulation - Hackthon Contest</h1>
          </span>
        </div>

        <div
          className="ruleContent"
          dangerouslySetInnerHTML={{ __html: guide }}
        />
      </div>
    </>
  );
}

export default RuleRegulation;
