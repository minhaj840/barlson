import React, { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import moment from "moment";
import { submitTestTime } from "../../../services/hackTest/hackTest";
import { useMutation, useQuery, useQueryClient } from "react-query";
import { toastApiError } from "../../../utils/toast/toast";
import { signoutHackthon } from "../../../utils/isAuth";

function Timer(props) {
  const queryClient = useQueryClient();

  const navigate = useNavigate();
  const location = useLocation();
  const [time, setTime] = useState(new Date());

  const mutation = useMutation(() => submitTestTime(), {
    onSuccess: () => {
      queryClient.invalidateQueries("test");
    },
  });

  // format date
  const date = moment(new Date(), "YYYY-MM-DD");
  const formattedDate = date.format("DD MMM YYYY");

  useEffect(() => {
    if (formattedDate === "28 Oct 2023" && time.getHours() >= 9) {
      const interval = setInterval(() => {
        setTime(new Date());
      }, 1000);
      return () => clearInterval(interval);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (formattedDate === "28 Oct 2023" && time.getHours() === 23) {
      // complete test
      mutation.mutate();
    }
    // props.setTime({ time: time.getHours(), date: formattedDate });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [time]);

  if (mutation.isError) {
    toastApiError(mutation.error);
  }
  useEffect(() => {
    if (mutation.isSuccess) {
      window.location.reload();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mutation.isSuccess]);
  return (
    <>
      <div className="container d-flex justify-content-between align-items-center gap-3">
        {location.pathname !== "/hackthon/student/start" &&
          formattedDate === "28 Oct 2023" &&
          time.getHours() >= 9 && (
            <button
              className="btn btn-danger"
              onClick={() => navigate("/hackthon/student/start")}
            >
              START TEST
            </button>
          )}

        <span>
          {" "}
          Current Date : <strong> {formattedDate} </strong>{" "}
        </span>
        <button class="btn btn-primary">
          Timer :{" "}
          {formattedDate === "28 Oct 2023" && time.getHours() >= 9
            ? time.toLocaleTimeString()
            : "10:0:0"}
        </button>
        {formattedDate === "28 Oct 2023" && time.getHours() >= 9 && (
          <button
            class="btn btn-danger"
            onClick={() => {
              // signoutHackthon();
              mutation.mutate();
              // window.location.reload();
            }}
          >
            End Test
          </button>
        )}
      </div>
      <hr />
    </>
  );
}

export default Timer;
