import { memo, useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import {
  toastApiError,
  toastError,
  toastSuccess,
} from "../../../utils/toast/toast";
import { Axios } from "../../../services/axios";

function LoginStudent({ show, handleClose }) {
  const [admin, setAdmin] = useState({
    email: "",
    name:"",
  });

  const [name,setName]=useState("");
  const [phone,setPhone]=useState();
  const [isLoading, setIsLoading] = useState(false);

  // onchange
  const handleChangetext = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setAdmin({ ...admin, [name]: value });
  };

  // handle submit
  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    const { email } = admin;
    try {
      if(!name){
        toastError("Name is required!");
      }
      if(!phone){
        toastError("Phone number is required!");
      }
      if (!email) {
        toastError("Email is required!");
      } else {
        // do signin
        const resp = await Axios.post("/hackTest/login", admin);

        if (resp?.status === 201) {
          toastSuccess("student login successfully");
          if (resp?.data) {
            localStorage.setItem(
              "studentHackthon",
              JSON.stringify({ token: resp?.data?.token, data: resp?.data })
            );
            setTimeout(() => {
              window.location.reload();
            }, 2000);
          } else {
            toastError("Unauthorized");
          }
        } else {
          toastError(resp?.data?.message);
        }
      }
    } catch (error) {
      toastApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Modal
        show={show}
        onHide={handleClose}
        animation={false}
        backdrop="static"
        keyboard={false}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>Student Login</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form className=" rounded border-1 p-3">
          <div class="mb-3">
              <label class="form-label" for="textInput">
                Name 
              </label>
              <input
                type="name"
                id="textInput"
                class="form-control"
                placeholder="Enter Your Name "
                name="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div class="mb-3">
              <label class="form-label" for="textInput">
               Phone Number
              </label>
              <input
                type="phone"
                id="textInput"
                class="form-control"
                placeholder="Enter Your Phone Number "
                name="phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>
            
            <div class="mb-3">
              <label class="form-label" for="textInput">
                Email - <span>Login with email at time of hackthon apply!</span>
              </label>
              <input
                type="email"
                id="textInput"
                class="form-control"
                placeholder="Enter registered email"
                name="email"
                value={admin.email}
                onChange={(e) => handleChangetext(e)}
              />
            </div>
          </form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button
            variant="primary"
            disabled={isLoading}
            onClick={(e) => handleLogin(e)}
          >
            Start Hackthon Test
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default memo(LoginStudent);
