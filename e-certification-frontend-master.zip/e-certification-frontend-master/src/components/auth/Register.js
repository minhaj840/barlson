import React, { useState } from "react";
import { isAdminAutheticated } from "../../utils/isAuth";
import AdminRegisterModel from "../../model/AdminLoginModel";
import NotFound from "../NotFound";
import AdminDash from "../dashboad/AdminDash";
import Sidebar from "../Sidebar";
import AdminDashboard from "../dashboad/adminDashboard";

function Register() {
  const { token } = isAdminAutheticated();
  // hide
  const [show, setShow] = useState(true);

  const handleClose = () => setShow(false);

  // <AdminDash />
  return (
    <div className="section mt-4 wrapper">
      <div className="container">
        {token ? (
          <AdminDash />
        ) : (
          <>
            <NotFound />
            <AdminRegisterModel show={show} handleClose={handleClose} />
          </>
        )}
      </div>
    </div>
  );
}

export default Register;
