import React, { memo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Axios } from "../../services/axios";
import Loader from "../../utils/loader/Loader";
import {
  toastApiError,
  toastError,
  toastSuccess,
} from "../../utils/toast/toast";
import { Col, Row } from "react-bootstrap";

function Login() {
  const navigate = useNavigate();

  const [credential, setCredential] = useState("");

  const [isLoading, setIsLoading] = useState(false);

  // handle submit
  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      if (!credential) {
        toastError("credentail is required!");
      } else {
        // do signin
        const resp = await Axios.post("/student/login", {
          credential: credential,
        });

        if (resp?.status === 201) {
          toastSuccess("student login successfully");
          if (resp?.data) {
            localStorage.setItem(
              "studentAuth",
              JSON.stringify({ token: resp?.data?.token, data: resp?.data })
            );
            setTimeout(() => {
              navigate("/student/profile");
              window.location.reload();
            }, 1000);
          } else {
            toastError("Unauthorized");
          }
        } else {
          toastError(resp?.data?.message);
        }
      }
    } catch (error) {
      toastApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Loader loader={isLoading} />

      <div className="section wrapper">
        <div className="container">
          <Row className="justify-content-center loginStudent">
            <Col lg={7}>
              <form
                className="h-100 border rounded border-1 p-3"
                onSubmit={handleLogin}
              >
                <div className="login">
                  <Loader />
                  <h4>Student Login 🔑</h4>
                </div>
                <div class="mb-3">
                  <label class="form-label" for="textInput">
                    Registered email or studentID
                  </label>
                  <input
                    type="text"
                    id="textInput"
                    class="form-control"
                    placeholder="Enter registered email or studentID"
                    onChange={(e) => setCredential(e.target.value)}
                  />
                </div>

                <div className="mt-3">
                  <button
                    className="btn btn-primary"
                    type="submit"
                    disabled={isLoading}
                  >
                    Login Student
                  </button>
                </div>
              </form>
            </Col>
          </Row>
        </div>
      </div>
    </>
  );
}

export default memo(Login);
