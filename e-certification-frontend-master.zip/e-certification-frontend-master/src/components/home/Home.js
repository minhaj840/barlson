import React from "react";
import { Alert } from "react-bootstrap";

function Home() {
  return (
    <div className="container">
      <div className="row">
        <div className="offset-lg-2 col-lg-8 col-md-12 col-12 text-center">
          <span
            className="fs-4 text-warning ls-md text-uppercase
 fw-semibold"
          >
            get things done
          </span>
          <h2 className="display-3 mt-4 mb-3  fw-bold">
            Just try it out! You’ll fall in love
          </h2>
          <p className="lead  px-lg-8 mb-6">
            Designed for modern website looking to download a simple, premium
            and your certificate.
          </p>
        </div>
        <div className="btnRow text-center">
          <a href="https://www.bqarlson.com/#/home">
            <button className="btn btn-outline-success">Go To Home</button>
          </a>
        </div>
      </div>
    </div>
  );
}

export default Home;
