import React from "react";
import Spinner from "react-bootstrap/Spinner";

export default function Loading() {
  return (
    <div style={{ height: "100vh" }}>
      <div className="d-flex w-100  align-items-center justify-content-center h-100">
        <Spinner animation="border" variant="success" />
      </div>
    </div>
  );
}
