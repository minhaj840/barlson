import { memo } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import CertificatePartView from "./CertificatePartView";
import { PDFViewer } from "@react-pdf/renderer";

function CertificationModel({ show, handleClose, data }) {
  return (
    <>
      <Modal
        show={show}
        onHide={handleClose}
        animation={false}
        backdrop="static"
        keyboard={false}
        centered
        size="lg"
      >
        <Modal.Header closeButton>
          <Modal.Title>Certification of Participation</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <PDFViewer style={{ width: "100%" }} height={500}>
            <CertificatePartView name={data?.name} />
          </PDFViewer>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default memo(CertificationModel);
