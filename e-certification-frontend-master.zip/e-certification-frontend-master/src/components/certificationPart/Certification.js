import React, { memo, useEffect, useState } from "react";
import { Col, Row } from "react-bootstrap";
import Loader from "../../utils/loader/Loader";
import { Axios } from "../../services/axios";
import { toastApiError, toastError } from "../../utils/toast/toast";
import CertificationModel from "./CertificationModel";
import { PDFViewer } from "@react-pdf/renderer";
import CertificatePartView from "./CertificatePartView";

function Certification() {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [show, setShow] = useState(false);
  const [data, setData] = useState([]);

  const handleSubmitEmail = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;

    const emailValid = emailRegex.test(email);

    try {
      if (!email) {
        toastError("email is  required!");
      } else if (!emailValid) {
        toastError("email must be a valid email");
      } else {
        const resp = await Axios.post("/hackthon/login", { email: email });

        if (resp?.status === 200) {
          setData(resp?.data?.data);
          setShow(true);
        } else {
          toastError(resp?.data?.message);
        }
      }
    } catch (error) {
      toastApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  // handle close
  const handleClose = () => {
    setShow(false);
  };

  return (
    <>
      {show && (
        <CertificationModel show={show} handleClose={handleClose} data={data} />
      )}

      <Loader loader={isLoading} />
      <div className="section wrapper">
        <div className="container">
          <Row className="justify-content-center loginStudent">
            <Col lg={7}>
              <form className="h-100 border rounded border-1 p-3">
                <div className="login">
                  <Loader />
                  <h4>Downlaod your certificate of participation 🤼</h4>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="textInput">
                    Registered email*
                  </label>
                  <input
                    type="text"
                    id="textInput"
                    class="form-control"
                    placeholder="Enter registered email"
                    name="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>

                <div className="mt-3 d-flex ">
                  <button
                    className="btn btn-primary"
                    type="submit"
                    disabled={isLoading}
                    onClick={(e) => handleSubmitEmail(e)}
                  >
                    Download certificate
                  </button>
                </div>
              </form>
            </Col>
          </Row>
        </div>
      </div>
    </>
  );
}

export default memo(Certification);
