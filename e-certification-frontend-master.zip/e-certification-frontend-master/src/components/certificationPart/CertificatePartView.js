import React from "react";
import {
  Document,
  Page,
  Text,
  View,
  Image,
  StyleSheet,
} from "@react-pdf/renderer";

// Create styles
const styles = StyleSheet.create({
  page: {
    padding: 10,
  },
  imageCon: {
    positon: "absolute",
    top: "0%",
  },
  textCon: {
    textAlign: "center",
    width: "100%",
    display: "flex",
    justifyContent: "center",
  },
  text: {
    width: "100%",
    textAlign: "center",
    position: "absolute",
    top: -227,
    zIndex: 99,
    fontSize: "30px",
    fontWeight: "bold",
    textTransform: "uppercase",
  },
});

// Create PDF component
const CertificatePartView = ({ name }) => (
  <Document>
    <Page size="a4" style={styles.page}>
      <View style={styles.imageCon}>
        <Image src="./cert/cert1.png" alt="Image" style={styles.image} />
      </View>

      <View style={styles.textCon}>
        <Text style={styles.text}>{name}</Text>
      </View>
    </Page>
  </Document>
);

export default CertificatePartView;
