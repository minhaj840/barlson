import React, { memo, useEffect, useState } from "react";
import StudentCard from "./StudentCard";
import {
  toastApiError,
  toastError,
  toastSuccess,
} from "../../utils/toast/toast";
import { useMutation, useQuery, useQueryClient } from "react-query";
import { addStudent, getAllStudent } from "../../services/auth/auth";
import Loader from "../../utils/loader/Loader";
import AllStudentModel from "../../model/AllStudentModel";
import { BiRefresh } from "react-icons/bi";

function AdminDash() {
  const queryClient = useQueryClient();

  const [studentData, setStudentData] = useState([]);
  const [admin, setAdmin] = useState({
    name: "",
    email: "",
    internRole: "",
    duration: "",
    startDate: "",
    roles: "student",
  });
  const [show, setShow] = useState(false);

  const [refresh, setRefresh] = useState(false);

  // model
  const handleClose = () => {
    setShow(false);
  };

  const handleOpen = () => {
    setShow(true);
  };

  //get all student
  const { isLoading, isSuccess, isError, error, data } = useQuery(
    "student",
    getAllStudent
  );

  // mutate
  const mutation = useMutation((data) => addStudent(data), {
    onSuccess: () => {
      queryClient.invalidateQueries("student");
    },
  });

  // onchange
  const handleChangetext = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setAdmin({ ...admin, [name]: value });
  };
  const hanldeInterhshipDuration = (e) => {
    const value = e.target.value;
    setAdmin({ ...admin, duration: value });
  };
  const handleInternRoles = (e) => {
    const value = e.target.value;
    setAdmin({ ...admin, internRole: value });
  };

  // add student
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const { name, email, internRole, duration, startDate } = admin;
      if (!name || !email || !duration || !startDate || !internRole) {
        toastError("please fill all the fields");
      } else {
        // mutate
        mutation.mutate(admin);
      }
    } catch (error) {
      toastApiError(error);
    }
  };

  // handleSearch
  const handleSearch = (e) => {
    const value = e.target.value;
    if (value) {
      const filterData = studentData.filter((stud) => {
        return stud.name.toLowerCase().includes(value.toLowerCase());
      });
      setStudentData(filterData);
    } else {
      setStudentData(data?.data?.data);
    }
  };

  if (mutation.isError) {
    toastApiError(mutation.error);
  }
  if (isError) {
    toastApiError(error);
  }

  // refresh page
  const refreshPage = () => {
    // refresh page
    setStudentData(data?.data?.data);
    setRefresh(true);
  };

  useEffect(() => {
    if (mutation.isSuccess) {
      setAdmin({
        name: "",
        email: "",
        internRole: "",
        duration: "",
        startDate: "",
        roles: "student",
      });
      // window.location.reload();
      toastSuccess("student added successfully");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mutation.isSuccess]);

  useEffect(() => {
    if (isSuccess) {
      setStudentData(data?.data?.data);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSuccess]);

  useEffect(() => {
    const interval = setTimeout(() => {
      setRefresh(false);
    }, [1000]);

    return () => clearTimeout(interval);
  },[refresh]);

  return (
    <>
      <Loader loader={isLoading || mutation.isLoading || refresh} />
      <AllStudentModel
        show={show}
        handleClose={handleClose}
        key={data?.data?.data}
      />

      <div className="leftWrapper">
        <section className="mt-5">
          <div className="showAllStudentBtn d-flex justify-content-end my-2">
            <button className="btn btn-success" onClick={() => handleOpen()}>
              All Student
            </button>
            <button
              className="mx-2 btn btn-danger"
              onClick={() => refreshPage()}
            >
              <BiRefresh size={30} />
            </button>
          </div>

          <div className="row h-100 sm:mt-4 border rounded-2 py-2">
            <div className="col-lg-7 ">
              <form className=" mx-auto" onSubmit={handleSubmit}>
                <div className="login">
                  <h4>
                    Student Register 🔐 -{" "}
                    <span className="fw-bold">{data?.data?.data?.length}</span>
                  </h4>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="textInput">
                    Student Name
                  </label>
                  <input
                    type="text"
                    id="textInput"
                    class="form-control"
                    placeholder="Enter student name"
                    name="name"
                    value={admin.name}
                    onChange={(e) => handleChangetext(e)}
                  />
                </div>
                <div class="mb-3">
                  <label class="form-label" for="textInput">
                    Student Email
                  </label>
                  <input
                    type="email"
                    id="textInput"
                    class="form-control"
                    placeholder="Enter registered email"
                    name="email"
                    value={admin.email}
                    onChange={(e) => handleChangetext(e)}
                  />
                </div>
                <div class="mb-3">
                  <label class="form-label" for="textInput">
                    Select roles
                  </label>

                  <select
                    class="form-select"
                    aria-label="Default select example"
                    onChange={(e) => handleInternRoles(e)}
                  >
                    <option selected disabled>
                      Select roles
                    </option>
                    <option value="Frontend Development">
                      Frontend Development - React js
                    </option>
                    <option value="Full Stack Development(node+react)">
                      Full stack Development - Node js
                    </option>
                    <option value="Full Stack Development(java+react)">
                      Full Stack Development - Java
                    </option>
                    <option value="Digital Marketing">Digital Marketing</option>
                    <option value="Graphics Design">Graphics Design</option>
                  </select>
                </div>
                <div class="mb-3">
                  <label class="form-label" for="textInput">
                    Select duration internship
                  </label>

                  <select
                    class="form-select"
                    aria-label="Default select example"
                    onChange={(e) => hanldeInterhshipDuration(e)}
                  >
                    <option selected disabled>
                      disabled
                    </option>
                    <option value="1 month">1 month</option>
                    <option value="2 month">2 month</option>
                    <option value="3 month">3 month</option>
                    <option value="6 month">6 month</option>
                  </select>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="textInput">
                    Start Date
                  </label>
                  <input
                    type="date"
                    id="textInput"
                    class="form-control"
                    placeholder="Enter student name"
                    name="startDate"
                    value={admin.startDate}
                    onChange={(e) => handleChangetext(e)}
                  />
                </div>
                <div className="mt-3">
                  <button className="btn btn-primary" type="submit">
                    Add Student
                  </button>
                </div>
              </form>
            </div>
            <div className="col-lg-5 sm:mt-3 border-start">
              <div className="studentcontainer studentList">
                <div className="studentSearch">
                  <input
                    type="text"
                    id="textInput"
                    className="form-control searchControl"
                    placeholder="Search student"
                    onChange={(e) => handleSearch(e)}
                  />
                </div>

                {isSuccess && (
                  <div class="row mt-2">
                    {studentData?.map((item, index) => {
                      return <StudentCard student={item} key={index} />;
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}

export default memo(AdminDash);
