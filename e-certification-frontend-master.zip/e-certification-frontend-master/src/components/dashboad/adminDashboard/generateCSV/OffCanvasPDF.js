import Offcanvas from "react-bootstrap/Offcanvas";
import { toastApiError, toastError } from "../../../../utils/toast/toast";
import { Axios } from "../../../../services/axios";
import { useEffect, useState } from "react";
import { isAdminAutheticated } from "../../../../utils/isAuth";
import Loader from "../../../../utils/loader/Loader";

function OffCanvasPDF(props) {
  const { token } = isAdminAutheticated();
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState([]);

  const getAllHackthon = async () => {
    setIsLoading(true);
    try {
      const resp = await Axios.get("/hackthon/all", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (resp?.status === 200) {
        setData(resp?.data?.data);
      } else {
        toastError(resp?.data?.message);
      }
    } catch (error) {
      toastApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    getAllHackthon();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <Offcanvas
        show={props.show}
        onHide={props.handleClose}
        placement="end"
        {...props}
      >
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>
            Participation Student - {data?.length}
          </Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <Loader loader={isLoading} />
          <div className="row">
            {data?.map((tag) => {
              return (
                <div className="col-12 mb-2 col-lg-12">
                  <div className="card p-2">
                    <div className="name d-flex flex-column gap-1">
                      <span>Name : {tag?.name} </span>
                      <span>Email : {tag?.email} </span>
                      <span>ID : {tag?._id} </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
}

export default OffCanvasPDF;
