import React, { memo, useState } from "react";

import { Col, Row } from "react-bootstrap";
import {
  toastApiError,
  toastError,
  toastSuccess,
} from "../../../../utils/toast/toast";
import { AxiosCyclic } from "../../../../services/axios";
import Loader from "../../../../utils/loader/Loader";
import OffCanvasPDF from "./OffCanvasPDF";
import { isAdminAutheticated } from "../../../../utils/isAuth";
import Papa from "papaparse";

function CSV() {
  const { token } = isAdminAutheticated();

  const [credential, setCredential] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const [show, setShow] = useState(false);

  const handleClose = () => {
    setShow(false);
  };
  const handleOpen = () => {
    setShow(true);
  };

  const handleCsvFile = (e) => {
    const file = e.target.files[0];
    Papa.parse(file, {
      worker: true,
      complete: function (results) {
        console.log(results?.data)
        setCredential(results?.data||[])
      },
      header: true,
      skipEmptyLines: true,
   
    });
  };

  // handle submit
  const handleUplaodCsv = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      if (!credential) {
        toastError("csv file is required!");
      } else {
        // do signin
        const resp = await AxiosCyclic.post(
          "/hackthon/csv",
          {
            data: credential,
          },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        if (resp?.status === 201) {
          toastSuccess("file uploaded successfully");
          if (resp?.data) {
            // do something
          } else {
            toastError("Unauthorized");
          }
        } else {
          toastError(resp?.data?.message);
        }
      }
    } catch (error) {
      toastApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  const options = {
    scroll: true,
    backdrop: false,
  };

  return (
    <>
      <div className="leftWrapper">
        <section className="mt-5">
          <OffCanvasPDF
            options={options}
            show={show}
            handleClose={handleClose}
            handleOpen={handleOpen}
            key={1}
          />
          <Loader loader={isLoading} />

          <div className="sectionCSV wrapper">
            <div className="container">
              <Row className="justify-content-center loginStudent">
                <Col lg={7}>
                  <div className="h-100 border rounded border-1 p-3">
                    <div className="login">
                      <Loader />
                      <h4>Upload csv file 📲</h4>
                    </div>
                    <div class="mb-3">
                      <label class="form-label" for="textInput">
                        upload csv file to generate certificate
                      </label>
                      <input
                        type="file"
                        id="textInput"
                        class="form-control"
                        accept=".csv"
                        placeholder="csv file"
                        name="csv"
                        onChange={(e) => handleCsvFile(e)}
                      />
                    </div>

                    <div className="mt-3">
                      <button
                        className="btn btn-primary"
                        type="submit"
                        disabled={isLoading}
                        onClick={(e) => handleUplaodCsv(e)}
                      >
                        Generate certificate of participation
                      </button>
                      <button
                        className="mx-4 btn btn-warning"
                        onClick={() => handleOpen()}
                      >
                        Open All Certification
                      </button>
                    </div>
                  </div>
                </Col>
              </Row>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}

export default memo(CSV);
