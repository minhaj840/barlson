import React, { memo, useEffect, useState } from "react";

import StudentHackCanvas from "../model/StudentHackCanvas1";
import QuestionModel from "../model/QuestionModel";

import QuestionCard from "./QuestionCard";
import { useQuery } from "react-query";
import { getQuestionToDb } from "../../../../../services/questions/ques";
import {
  toastApiError,
  toastError,
  toastSuccess,
} from "../../../../../utils/toast/toast";
import Loader from "../../../../../utils/loader/Loader";
import { Axios } from "../../../../../services/axios";
import { isAdminAutheticated } from "../../../../../utils/isAuth";
import GuideLineModel from "../model/GuideLineModel";

function Question() {
  const { token } = isAdminAutheticated();

  const [guidline, setGuidline] = useState(false);

  const [show, setShow] = useState(false);
  const [loader, setLoader] = useState(false);

  const [showQues, setShowQues] = useState(false);
  const [questions, setQuestions] = useState([]);
  // retreive all question

  //get all student
  const { isLoading, isSuccess, isError, error, data } = useQuery(
    "questions",
    getQuestionToDb
  );

  const handleCloseQues = () => {
    setShowQues(false);
  };

  const handleClose = () => {
    setShow(false);
  };

  const handelCloseGuideline = () => {
    setGuidline(false);
  };
  const handleOpen = () => {
    setShow(true);
  };

  const options = {
    scroll: true,
    backdrop: false,
  };
  if (isError) {
    toastApiError(error);
  }

  // handleDistributedQuestion
  const handleDistributedQuestion = async () => {
    setLoader(true);
    try {
      const resp = await Axios.get("/hackTest/merge/question", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (resp?.status === 201) {
        toastSuccess("question successfully distributed");
        setLoader(false);
      } else {
        toastError("somthing error happended");
        setLoader(false);
      }
    } catch (error) {
      toastApiError(error);
    } finally {
      setLoader(false);
    }
  };

  useEffect(() => {
    if (isSuccess) {
      setQuestions(data?.data?.data);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSuccess]);

  return (
    <>
      <QuestionModel show={showQues} handleClose={handleCloseQues} />
      <GuideLineModel show={guidline} handleClose={handelCloseGuideline} />
      {/** for upload student as csv file */}
      <StudentHackCanvas
        options={options}
        show={show}
        handleClose={handleClose}
        handleOpen={handleOpen}
        key={1}
      />
      <Loader loader={isLoading || loader} />
      <div className="leftWrapper">
        <div className="mt-5 d-flex justify-content-between">
          <div className="questitle">
            <h3>All Question - {questions?.length}</h3>
          </div>
          <div className="d-flex gap-2">
            <button className="btn btn-info" onClick={() => setGuidline(true)}>
              Create Hackthon Guideline
            </button>
            <button
              className="btn btn-dark"
              onClick={() => handleDistributedQuestion()}
              disabled={data?.data?.data?.length === 0 ? true : false}
            >
              Distribute Question To students
            </button>
            <button
              className="btn btn-primary"
              onClick={() => setShowQues(true)}
            >
              Add Question
            </button>
            <button className=" btn btn-warning " onClick={() => handleOpen()}>
              Uplaod student CSV File
            </button>
          </div>
        </div>
        <hr />

        {questions?.map((tag, index) => {
          return <QuestionCard tag={tag} key={index} index={index} />;
        })}
      </div>
    </>
  );
}

export default memo(Question);
