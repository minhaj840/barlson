import React, { memo } from "react";
import { isError, useMutation, useQueryClient } from "react-query";
import { deleteQuestionToDb } from "../../../../../services/questions/ques";
import Loader from "../../../../../utils/loader/Loader";
import { toastApiError } from "../../../../../utils/toast/toast";

function QuestionCard({ tag, index }) {
  const queryClient = useQueryClient();

  const mutation = useMutation((data) => deleteQuestionToDb(data), {
    onSuccess: () => {
      queryClient.invalidateQueries("questions");
    },
  });

  if (mutation.isError) {
    toastApiError(mutation.error);
  }

  return (
    <>
      <Loader loader={mutation.isLoading} />
      <div className="d-flex justify-content-end">
        <button
          class="btn btn-danger btn-sm"
          onClick={() => {
            mutation.mutate(tag?._id);
            window.location.reload();
          }}
        >
          Delete
        </button>
      </div>
      <div className="mb-3 accordion" id="accordionExampleY">
        <div className="accordion-item">
          <h2 className="accordion-header" id="headingOneY">
            <button
              className="accordion-button d-flex justify-content-center align-items-center"
              type="button"
              data-mdb-toggle="collapse"
              data-mdb-target={`#collapseOneY_${index}`}
              aria-expanded="true"
              aria-controls={`collapseOneY_${index}`}
            >
              <span className="fw-medium fs-5">
                {index + 1} - {tag?.title}
              </span>
            </button>
          </h2>
          <div
            id={`collapseOneY_${index}`}
            className="accordion-collapse collapse close"
            aria-labelledby="headingOneY"
            data-mdb-parent="#accordionExampleY"
          >
            <div
              className="accordion-body"
              dangerouslySetInnerHTML={{ __html: tag?.description }}
            />
          </div>
        </div>
      </div>
    </>
  );
}

export default memo(QuestionCard);
