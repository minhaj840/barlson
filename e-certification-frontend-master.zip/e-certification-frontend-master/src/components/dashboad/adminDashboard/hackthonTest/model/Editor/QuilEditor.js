import React from "react";
import ReactQuill from "react-quill";
import { formats, modules } from "./editorModule";

function QuilEditor({ value = "", handleProcedureContentChange }) {
  return (
    <ReactQuill
      theme="snow"
      modules={modules}
      defaultValue={value}
      formats={formats}
      placeholder="write your content ...."
      onChange={handleProcedureContentChange}
      style={{ height: "220px" }}
    />
  );
}

export default QuilEditor;
