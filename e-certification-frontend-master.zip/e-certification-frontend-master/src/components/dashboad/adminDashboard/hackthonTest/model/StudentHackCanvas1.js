import Offcanvas from "react-bootstrap/Offcanvas";
import { useEffect, useState } from "react";
import { isAdminAutheticated } from "../../../../../utils/isAuth";
import { Axios, AxiosCyclic } from "../../../../../services/axios";
import {
  toastApiError,
  toastError,
  toastSuccess,
} from "../../../../../utils/toast/toast";
import Loader from "../../../../../utils/loader/Loader";
import Papa from "papaparse";

function StudentHackCanvas(props) {
  const [credential, setCredential] = useState([]);

  const { token } = isAdminAutheticated();
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState([]);

  const getAllHackthon = async () => {
    setIsLoading(true);
    try {
      const resp = await Axios.get("/hackTest/allStudent", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (resp?.status === 200) {
        setData(resp?.data?.data);
      } else {
        toastError(resp?.data?.message);
      }
    } catch (error) {
      toastApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    getAllHackthon();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleCsvFile = (e) => {
    const file = e.target.files[0];
    Papa.parse(file, {
      worker: true,
      complete: function (results) {
        console.log(results?.data);
        setCredential(results?.data || []);
      },
      header: true,
      skipEmptyLines: true,
    });
  };

  // handle submit
  const handleUplaodCsv = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      if (!credential) {
        toastError("csv file is required!");
      } else {
        // do signin
        const resp = await AxiosCyclic.post(
          "/hackTest/csv",
          {
            data: credential,
          },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        if (resp?.status === 201) {
          toastSuccess("file uploaded successfully");
          if (resp?.data) {
            // do something
            getAllHackthon();
          } else {
            toastError("Unauthorized");
          }
        } else {
          toastError(resp?.data?.message);
        }
      }
    } catch (error) {
      toastApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Offcanvas
        show={props.show}
        onHide={props.handleClose}
        placement="end"
        {...props}
      >
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>
            Participation Student - {data?.length}
          </Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <div className="border rounded border-1 p-3">
            <div className="login">
              <Loader />
              <h4>Upload csv file 📲</h4>
            </div>
            <div class="mb-3">
              <label class="form-label" for="textInput">
                uplaod student csv file only
              </label>
              <input
                type="file"
                id="textInput"
                class="form-control"
                accept=".csv"
                placeholder="csv file"
                name="csv"
                onChange={(e) => handleCsvFile(e)}
              />
            </div>

            <div className="mt-3">
              <button
                className="btn btn-primary"
                type="submit"
                disabled={isLoading}
                onClick={(e) => handleUplaodCsv(e)}
              >
                Add Student For Hackthon
              </button>
            </div>
          </div>

          <Loader loader={isLoading} />
          <div className="row">
            {data?.map((tag) => {
              return (
                <div className="col-12 mb-2 col-lg-12">
                  <div className="card p-2">
                    <div className="name d-flex flex-column gap-1">
                      <span>Name : {tag?.name} </span>
                      <span>Email : {tag?.email} </span>
                      <span>Collge Name : {tag?.collegeName} </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
}

export default StudentHackCanvas;
