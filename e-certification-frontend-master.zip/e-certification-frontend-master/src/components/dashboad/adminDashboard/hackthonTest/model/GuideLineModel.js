import { memo, useCallback, useEffect, useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import "quill/dist/quill.snow.css";
import QuilEditor from "./Editor/QuilEditor";
import { toastApiError, toastError } from "../../../../../utils/toast/toast";
import { useMutation, useQuery, useQueryClient } from "react-query";
import {
  addGuideLine,
  getGuideLine,
} from "../../../../../services/hackTest/hackTest";

function LoginStudent({ show, handleClose }) {
  const queryClient = useQueryClient();
  const [value, setValue] = useState("<b>Create Guidline</b>");

  const mutation = useMutation((data) => addGuideLine(data), {
    onSuccess: () => {
      queryClient.invalidateQueries("guideline");
    },
  });

  //get all student
  const { isLoading, isSuccess, isError, error, data } = useQuery(
    "guideline",
    getGuideLine
  );

  const [question, setQuestion] = useState({
    name: "guideline",
    description: "",
  });

  const handleProcedureContentChange = useCallback(
    (content) => {
      setQuestion({ ...question, description: content });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [question.description]
  );

  // handle submit
  const addQuestion = async () => {
    const { description } = question;
    try {
      if (!description) {
        toastError("All fields are required");
      } else {
        //  send
        mutation.mutate(question);
      }
    } catch (error) {
      toastApiError(error);
    }
  };

  if (mutation.isError) {
    toastApiError(mutation.error);
  }
  if (isError) {
    toastApiError(error);
  }

  useEffect(() => {
    if (mutation.isSuccess) {
      window.location.reload();
      handleClose();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mutation.isSuccess]);

  useEffect(() => {
    if (isSuccess) {
      setValue(data?.data?.data?.description);
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSuccess]);

  return (
    <>
      <Modal
        show={show}
        onHide={handleClose}
        animation={false}
        backdrop="static"
        keyboard={false}
        size={"lg"}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>Add Hackthon Guideline</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form className=" rounded border-1 p-3">
            <div class="mb-3">
              <label class="form-label" for="textInput">
                Guideline*
              </label>
              {value && (
                <QuilEditor
                  value={value}
                  handleProcedureContentChange={handleProcedureContentChange}
                />
              )}
            </div>
          </form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button
            variant="primary"
            disabled={mutation.isLoading}
            onClick={() => addQuestion()}
          >
            Create Guideline
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default memo(LoginStudent);
