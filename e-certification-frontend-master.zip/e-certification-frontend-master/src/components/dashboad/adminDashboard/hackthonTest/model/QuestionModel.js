import { memo, useCallback, useEffect, useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import "quill/dist/quill.snow.css";
import QuilEditor from "./Editor/QuilEditor";
import { toastApiError, toastError } from "../../../../../utils/toast/toast";
import { useMutation, useQueryClient } from "react-query";
import { addQuestionToDb } from "../../../../../services/questions/ques";

function LoginStudent({ show, handleClose }) {
  const queryClient = useQueryClient();

  const mutation = useMutation((data) => addQuestionToDb(data), {
    onSuccess: () => {
      queryClient.invalidateQueries("questions");
    },
  });

  const [question, setQuestion] = useState({
    title: "",
    description: "",
  });

  const handleProcedureContentChange = (content) => {
    setQuestion({ ...question, description: content });
  };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  // [question.content]
  //   );
  // onchange
  const handleChangetext = useCallback(
    (e) => {
      const name = e.target.name;
      const value = e.target.value;
      setQuestion({ ...question, [name]: value });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [question.title]
  );

  // handle submit
  const addQuestion = async () => {
    const { title, description } = question;
    try {
      if (!title || !description) {
        toastError("All fields are required");
      } else {
        //  send
        mutation.mutate(question);
      }
    } catch (error) {
      toastApiError(error);
    }
  };

  if (mutation.isError) {
    toastApiError(mutation.error);
  }

  useEffect(() => {
    if (mutation.isSuccess) {
      window.location.reload();
      handleClose();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mutation.isSuccess]);

  return (
    <>
      <Modal
        show={show}
        onHide={handleClose}
        animation={false}
        backdrop="static"
        keyboard={false}
        size={"lg"}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>Add Question</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form className=" rounded border-1 p-3">
            <div class="mb-3">
              <label class="form-label" for="textInput">
                Title
              </label>
              <input
                type="text"
                id="textInput"
                class="form-control"
                placeholder="title"
                name="title"
                value={question.title}
                onChange={(e) => handleChangetext(e)}
              />
            </div>

            <div class="mb-3">
              <label class="form-label" for="textInput">
                Description
              </label>
              <QuilEditor
                handleProcedureContentChange={handleProcedureContentChange}
              />
            </div>
          </form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button
            variant="primary"
            disabled={mutation.isLoading}
            onClick={() => addQuestion()}
          >
            Add Question
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default memo(LoginStudent);
