import React from "react";
import AnswerCard from "./AnswerCard";
import { useQuery } from "react-query";
import { allStudentCompletedTest } from "../../../../../services/hackTest/hackTest";
import Loader from "../../../../../utils/loader/Loader";
import { toastApiError } from "../../../../../utils/toast/toast";

function Answer() {
  const { isLoading, isError, error, data } = useQuery(
    "test",
    allStudentCompletedTest
  );

  if (isError) {
    toastApiError(error);
  }

  return (
    <>
      <Loader loader={isLoading} />
      <div className="leftWrapper">
        <div className="mt-5 h3Title">
          <h3>All Submission - {data?.data?.data?.length}</h3>
        </div>

        <div className="row mt-3">
          {data?.data?.data?.map((stud, index) => {
            return <AnswerCard stud={stud} index={index} key={index} />;
          })}
        </div>
      </div>
    </>
  );
}

export default Answer;
