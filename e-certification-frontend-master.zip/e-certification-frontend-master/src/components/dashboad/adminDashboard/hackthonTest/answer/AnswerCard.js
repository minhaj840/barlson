import React, { useState } from "react";
import AnswerOffCanvas from "./AnswerOffCanvas";

function AnswerCard({ stud, index }) {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleOpen = () => setShow(true);

  return (
    <>
      <AnswerOffCanvas
        key={index}
        show={show}
        handleClose={handleClose}
        data={stud}
      />
      {
        <div className="col-lg-4 mb-4 col-md-6 col-sm-12 col-12">
          <div class="card">
            <div class="card-body">
              <span class="card-title">Name : {stud?.name}</span>
              <br />
              <span class="card-title">Email : {stud?.email}</span>
              <br />
              <span class="card-title">contact : {stud?.contact}</span>
              <br />
              <button class="mt-1 btn btn-primary" onClick={() => handleOpen()}>
                Details
              </button>
            </div>
          </div>
        </div>
      }
    </>
  );
}

export default AnswerCard;
