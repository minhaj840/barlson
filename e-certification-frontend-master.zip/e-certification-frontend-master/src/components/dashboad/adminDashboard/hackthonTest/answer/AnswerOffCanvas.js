import Offcanvas from "react-bootstrap/Offcanvas";

function AnswerOffCanvas(props) {
  return (
    <>
      <Offcanvas
        show={props.show}
        onHide={props.handleClose}
        placement="end"
        {...props}
      >
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>
            {props.data?.name}
            <hr />
          </Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <div>
            <div className="row">
              <div className="col-md-6">Name</div>
              <div className="col-md-6">{props?.data?.name}</div>
            </div>
            <div className="row">
              <div className="col-md-6">email</div>
              <div className="col-md-6">{props?.data?.email}</div>
            </div>
            <div className="row">
              <div className="col-md-6">Contact Number</div>
              <div className="col-md-6">{props?.data?.contact}</div>
            </div>
            <div className="row">
              <div className="col-md-6">Graduation Complete</div>
              <div className="col-md-6">{props?.data?.graduationComplete}</div>
            </div>
            <div className="row">
              <div className="col-md-6">Stream</div>
              <div className="col-md-6">{props?.data?.stream}</div>
            </div>

            <div className="my-3">
              <h5>Questions</h5>
              <hr />
              <div className="mt-3">
                {props?.data?.question?.map((ques, index) => {
                  return (
                    <div className="mb-1 accordion" id="accordionExampleY">
                      <div className="accordion-item">
                        <h2 className="accordion-header" id="headingOneY">
                          <button
                            className="accordion-button d-flex justify-content-center align-items-center"
                            type="button"
                            data-mdb-toggle="collapse"
                            data-mdb-target={`#collapseOneY_${index}`}
                            aria-expanded="true"
                            aria-controls={`collapseOneY_${index}`}
                          >
                            <span className="fw-medium fs-6">
                              {index + 1} - {ques?.title}
                            </span>
                          </button>
                        </h2>
                        <div
                          id={`collapseOneY_${index}`}
                          className="accordion-collapse collapse close"
                          aria-labelledby="headingOneY"
                          data-mdb-parent="#accordionExampleY"
                        >
                          <div
                            className="accordion-body"
                            dangerouslySetInnerHTML={{
                              __html: ques?.description,
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="my-3">
              <h5>Answers - Github</h5>
              <hr />

              <div className="mt-2">
                {props?.data?.answers?.map((tag, index) => {
                  return (
                    <>
                      <div class="mb-3" key={index}>
                        <input
                          type="text"
                          id="textInput"
                          class="form-control"
                          value={tag?.githubUrl}
                        />
                      </div>
                    </>
                  );
                })}
              </div>
            </div>

            <div className="my-3">
              <h5>Answers - Website</h5>
              <hr />

              <div className="mt-2">
                {props?.data?.answers?.map((tag, index) => {
                  return (
                    <>
                      <div class="mb-3" key={index}>
                        <input
                          type="text"
                          id="textInput"
                          class="form-control"
                          value={tag?.deployUrl}
                        />
                      </div>
                    </>
                  );
                })}
              </div>
            </div>
          </div>
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
}

export default AnswerOffCanvas;
