import React from "react";

function Poster() {
  return (
    <div className="leftWrapper">
      <section className="mt-5">
        <div className="posterContainer">

        <div className="my-3 d-flex justify-content-between">
        <h4>
        POSTER
        </h4>
        <button className="btn btn-primary">UPLOAD NEW</button>
        </div>

          <div class="row card-group">
            {[...new Array(20)].map((pos) => {
              return (
                <div className="mb-4 col-12 col-lg-4 col-md-4 col-sm-6">
                  <div class="card">
                    <img
                      src="https://mdbcdn.b-cdn.net/img/new/standard/city/042.webp"
                      class="card-img-top"
                      alt="Palm Springs Road"
                    />
                    <div class="card-body">
                      <button className="btn btn-secondary my-2">
                      DOWNLOAD 
                      </button>
                      <p class="card-text">
                        <small class="text-muted">
                          Last updated 3 mins ago
                        </small>
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Poster;
