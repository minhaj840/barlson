import React, { memo, useEffect, useState } from "react";

import { Col, Row } from "react-bootstrap";
import {
  toastApiError,
  toastError,
  toastSuccess,
} from "../../../../utils/toast/toast";
import { Axios } from "../../../../services/axios";
import Loader from "../../../../utils/loader/Loader";
import { isAdminAutheticated } from "../../../../utils/isAuth";
import QuilEditor from "./QuilEditor";
import Select from "react-select";
import makeAnimated from "react-select/animated";

const animatedComponents = makeAnimated();

function SendEmail() {
  const [state, setState] = useState({
    email: [],
    subject: "",
    html: "",
  });
  const [emailStud, setEmailStud] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState([]);

  const { token } = isAdminAutheticated();

  const [isLoading, setIsLoading] = useState(false);

  const handleProcedureContentChange = (content) => {
    console.log(content);
    setState({ ...state, html: content });
  };
  // eslint-disable-next-line react-hooks/exhaustive-deps

  //   select email
  const selectEmail = (selected) => {
    setSelectedOptions(selected);
    setState({ ...state, email: selected });
  };
  const handleSubject = (e) => {
    setState({ ...state, subject: e.target.value });
  };

  // handle submit
  const handleSendEmail = async (e) => {
    e.preventDefault();

    const { email, subject, html } = state;

    if (email.length !== 0) {
      if (!subject || !html) {
        return toastError("all fields are required");
      } else {
        setIsLoading(true);
        try {
          // do signin
          const resp = await Axios.post(
            "/sendMail",
            {
              state,
            },
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
          if (resp?.status === 201) {
            toastSuccess("mail send successfully");
            if (resp?.data) {
              // do something
            } else {
              toastError("Unauthorized");
            }
          } else {
            toastError(resp?.data?.message);
          }
        } catch (error) {
          toastApiError(error);
        } finally {
          setIsLoading(false);
        }
      }
    } else {
      toastError("Email is required");
    }
  };

  useEffect(() => {
    const fetchEmail = async () => {
      const resp = await Axios.get(
        "/student/getAll",

        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (resp?.status === 201) {
        setEmailStud(resp?.data?.data);
      }
    };
    fetchEmail();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <div className="leftWrapper">
        <section className="mt-5">
          <Loader loader={isLoading} />

          <div className="sectionCSV1 wrapper1">
            <div className="container1">
              <Row className="justify-content-center1">
                <Col lg={12}>
                  <div className="h-100   card">
                    <div className="login">
                      <Loader />
                      <h4>Send Email 📲</h4>
                    </div>
                    <div class="mb-3">
                      <label class="form-label" for="textInput">
                        Select Email
                      </label>

                      <Select
                        closeMenuOnSelect={false}
                        components={animatedComponents}
                        defaultValue={[]}
                        isMulti
                        options={(emailStud || []).map((tag) => ({
                          value: tag.email,
                          label: tag.email,
                        }))}
                        onChange={(e) => selectEmail(e)}
                        value={selectedOptions} // Bind the selectedOptions state to the value prop
                      />
                    </div>
                    <div class="mb-3">
                      <label class="form-label" for="textInput">
                        Subject*
                      </label>
                      <input
                        type="text"
                        id="textInput"
                        class="form-control"
                        placeholder="subject"
                        name="subject"
                        value={state.subject}
                        onChange={(e) => handleSubject(e)}
                      />
                    </div>
                    <div class="mb-3">
                      <label class="form-label" for="textInput">
                        Message*
                      </label>
                      <div
                        style={{
                          display: "grid1",
                          justifyContent: "center1",
                        }}
                      >
                        {"value" && (
                          <QuilEditor
                            handleProcedureContentChange={
                              handleProcedureContentChange
                            }
                          />
                        )}
                      </div>
                    </div>

                    <div className="mt-5">
                      <button
                        className="btn btn-danger "
                        type="submit"
                        disabled={isLoading}
                        onClick={(e) => handleSendEmail(e)}
                      >
                        send email
                      </button>
                    </div>
                  </div>
                </Col>
              </Row>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}

export default memo(SendEmail);
