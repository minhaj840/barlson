import moment from "moment";
import React, { useEffect, useState } from "react";
import AmbassadorPdfModel from "./AmbassadorPdfModel";
import Swal from "sweetalert2";
import { toastApiError } from "../../../utils/toast/toast";
import { useMutation, useQueryClient } from "react-query";
import Loader from "../../../utils/loader/Loader";
import {
  deleteAmbassador,
  updateAmbassadorStatus,
} from "../../../services/ambassdor/ambassdor";

function AmbassadorCard({ tag }) {
  const queryClient = useQueryClient();

  const [show, setShow] = useState(false);
  const [previewData, setPreviewData] = useState([]);
  const issuesDate = moment(tag?.startDate).format("DD MMM YYYY");

  // update certificate issues
  const mutation = useMutation((id) => updateAmbassadorStatus(id), {
    onSuccess: () => {
      queryClient.invalidateQueries("");
    },
  });
  const mutationDelete = useMutation((id) => deleteAmbassador(id), {
    onSuccess: () => {
      queryClient.invalidateQueries("");
    },
  });

  const handleClose = () => {
    setShow(false);
  };

  //   preview
  const preViewModel = (data) => {
    setPreviewData(data);
    setShow(true);
  };

  if (mutation.isError) {
    toastApiError(mutation.error);
  }
  if (mutationDelete.isError) {
    toastApiError(mutationDelete.error);
  }

  useEffect(() => {
    if (mutationDelete.isSuccess || mutation.isSuccess) {
      window.location.reload();
    }
  }, [mutationDelete.isSuccess, mutation.isSuccess]);

  // CONFIRM BOX
  const ConfirmBox = () => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        mutationDelete.mutate(tag._id);
        Swal.fire("Deleted!", "Student has been deleted.", "success");
      }
    });
  };

  // const PdfLayoutModel = () => {
  //   return (
  //     <AmbassadorPdfModel
  //       show={show}
  //       hanldeClose={handleClose}
  //       data={previewData}
  //     />
  //   );
  // };

  // useEffect(() => {
  //   PdfLayoutModel();
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [previewData]);

  return (
    <>
      <AmbassadorPdfModel
        key={tag}
        show={show}
        handleClose={handleClose}
        data={tag}
      />
      <Loader loader={mutation.isLoading} />
      <Loader loader={mutationDelete.isLoading} />
      <div className="col-md-6 col-lg-4 pb-3" key={tag._id}>
        <div className="card card-custom bg-white border-white border-0">
          <div className="card-custom-img"></div>
          <div className="card-custom-avatar">
            <img className="img-fluid" src={tag?.profile} alt="Avatar" />
          </div>
          <div className="card-body" style={{ overflowY: "auto" }}>
            <h4 className="card-title">{tag?.name}</h4>

            <div className="mt-2 d-flex flex-column">
              <span>Email : {tag?.email}</span>
              <span>Collge Name : {tag?.collgeName}</span>
              <span>ID : {tag?.ID}</span>
              <span>Issues Date : {issuesDate}</span>
              <span className="mt-2">
                <button
                  className="btn btn-info btn-sm"
                  onClick={() => preViewModel(tag)}
                >
                  Preview
                </button>
              </span>
            </div>
          </div>
          <div
            className="card-footer"
            style={{
              background: "inherit",
              borderColor: "inherit",
            }}
          >
            <button
              className="btn btn-primary"
              onClick={() => mutation.mutate(tag?._id)}
              style={{ background: tag?.isIssued ? "green" : "blue" }}
            >
              Issues ID
            </button>
            <button
              href="#"
              className="btn btn-danger mx-4"
              onClick={() => ConfirmBox()}
            >
              Remove
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

export default AmbassadorCard;
