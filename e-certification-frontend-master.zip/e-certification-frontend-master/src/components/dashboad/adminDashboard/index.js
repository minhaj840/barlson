import React, { Suspense, lazy, memo, useState } from "react";
import { Routes, Route } from "react-router-dom";
import Sidebar from "../../Sidebar";
import Loading from "../../Loading";
import AdminRegisterModel from "../../../model/AdminLoginModel";
import { isAdminAutheticated } from "../../../utils/isAuth";
import NotFound from "../../NotFound";

// import AdminDash from "../AdminDash";
// import AllStudent from "./AllStudent";
// import Ambassador from "./Ambassador";
// import Loading from "./components/Loading";


// add lazy loading
const AdminDash = lazy(() => import("../AdminDash"));
const AllStudent = lazy(() => import("./AllStudent"));
const Ambassador = lazy(() => import("./Ambassador"));
const Poster = lazy(() => import("./Poster"));
const CSV = lazy(() => import("./generateCSV/CSV"));
const SendEmail = lazy(() => import("./sendEmail/sendEmail"));
const Question = lazy(() => import("./hackthonTest/questions/Question"));
const Answer = lazy(() => import("./hackthonTest/answer/Answer"));

function AdminDashboard() {
  const { token } = isAdminAutheticated();
  const [show, setShow] = useState(true);

  // model
  const handleClose = () => {
    setShow(false);
  };



  return (
    <>
      {!token && (
        <>
          <AdminRegisterModel show={show} handleClose={handleClose} />
          <NotFound />
        </>
      )}

      {token && (
        <div className="row flex-wrap">
          <div className="fixedSideBar" style={{ width: "19%" }}>
            <Sidebar />
          </div>
          <div style={{ width: "80%", position: "absolute", right: 0 }}>
            <Routes>
              <Route
                path="/"
                element={
                  <Suspense fallback={<Loading />}>
                    <AdminDash />
                  </Suspense>
                }
              />
              <Route
                path="/allStudent"
                element={
                  <Suspense fallback={<Loading />}>
                    <AllStudent />
                  </Suspense>
                }
              />

              <Route
                path="/campus"
                element={
                  <Suspense fallback={<Loading />}>
                    <Ambassador />
                  </Suspense>
                }
              />

              <Route
                path="/csv"
                element={
                  <Suspense fallback={<Loading />}>
                    <CSV />
                  </Suspense>
                }
              />

              <Route
                path="/hackthon_question"
                element={
                  <Suspense fallback={<Loading />}>
                    <Question />
                  </Suspense>
                }
              />
              <Route
                path="/hackthon_solution"
                element={
                  <Suspense fallback={<Loading />}>
                    <Answer />
                  </Suspense>
                }
              />

              <Route
                path="/email"
                element={
                  <Suspense fallback={<Loading />}>
                    <SendEmail />
                  </Suspense>
                }
              />
              <Route
                path="/poster"
                element={
                  <Suspense fallback={<Loading />}>
                    <Poster />
                  </Suspense>
                }
              />
            </Routes>
          </div>
        </div>
      )}
    </>
  );
}

export default memo(AdminDashboard);
