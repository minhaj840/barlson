import { Modal } from "react-bootstrap";
import React from "react";
import AmbassdorPdf from "../../ambassdor/ambasdorPdf/Pdf";
import { PDFViewer } from "@react-pdf/renderer";

function AmbassadorPdfModel({ show, handleClose, data }) {
  const previewData = { data };

  return (
    <>
      <Modal
        show={show}
        animation={true}
        size={"lg"}
        centered
        onHide={handleClose}
      >
        <Modal.Header closeButton>
          <Modal.Title>ID CARD VIEWER</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <PDFViewer style={{ width: "100%" }} height={"1000"}>
            <AmbassdorPdf data={previewData} />
          </PDFViewer>
        </Modal.Body>
        <Modal.Footer></Modal.Footer>
      </Modal>
    </>
  );
}

export default AmbassadorPdfModel;
