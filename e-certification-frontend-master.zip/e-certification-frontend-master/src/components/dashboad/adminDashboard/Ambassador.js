import React, { memo, useEffect, useState } from "react";
import Loader from "../../../utils/loader/Loader";
import { useQuery } from "react-query";
import { toastApiError } from "../../../utils/toast/toast";
import { getAllCampusAmbassador } from "../../../services/ambassdor/ambassdor";
import AmbassadorCard from "./AmbassadorCard";

function Ambassador() {
  const [studentData, setStudentData] = useState([]);
  //get all student
  const { isLoading, isSuccess, isError, error, data } = useQuery(
    "",
    getAllCampusAmbassador
  );

  if (isError) {
    toastApiError(error);
  }



  useEffect(() => {
    if (isSuccess) {
      setStudentData(data?.data);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSuccess]);



  return (
    <>
      <div className="leftWrapper">
        <section className="mt-5">
          <div className="tableStudent">
            <Loader loader={isLoading} />
            {/*Ambassdor data */}
            <h3>Campus Ambassador</h3>
            <hr />

            <div>
              <div className="row pt-2 m-auto">
                {

                    studentData?.data?.length>0?
                    studentData?.data?.map((tag) => {
               
                    return (
                        <AmbassadorCard tag={tag} key={tag._id}/>
                    )
               
                }):<h3>No Campus Registered Yet!</h3>
            }
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}

export default memo(Ambassador);
