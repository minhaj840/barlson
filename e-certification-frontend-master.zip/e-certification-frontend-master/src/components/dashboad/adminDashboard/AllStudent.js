import React, { memo, useEffect, useState } from "react";
import { getAllStudent } from "../../../services/auth/auth";
import { useQuery } from "react-query";
import { toastApiError } from "../../../utils/toast/toast";

import Loader from "../../../utils/loader/Loader";

function AllStudent() {
  const [studentData, setStudentData] = useState([]);
  //get all student
  const { isLoading, isSuccess, isError, error, data } = useQuery(
    "student",
    getAllStudent
  );

  if (isError) {
    toastApiError(error);
  }

  useEffect(() => {
    if (isSuccess) {
      setStudentData(data?.data?.data);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSuccess]);

  const table = new window.Tabulator("#table", {
    layout: "fitColumns",
    resizableColumnFit: true,
    responsiveLayout: "hide",
    resizableRows: true,
    pagination: "local",
    paginationSize: 25,
    paginationSizeSelector: [10, 25,50, 100],
    movableColumns: true,
    paginationCounter: "rows",

    data: studentData,
    columns: [
      { title: "Name", field: "name", width: 200, resizable: true },
      { title: "Role", field: "internRole", resizable: true },
      { title: "Duration", field: "duration", resizable: true },
      { title: "StudentId", field: "studentID", resizable: true },
      { title: "Email", field: "email", resizable: true },
      { title: "Start Date", field: "startDate", resizable: true },
      { title: "isCompleted", field: "isCourseCompleted", resizable: true },
    ],
  });

  //Trigger setFilter function with correct parameters
  function updateFilter(e) {
    const value = e.target.value;
    table.setFilter("name", "like", value);
  }

  return (
    <div className="leftWrapper">
      <section className="mt-5">
        <div className="tableStudent">
          <Loader loader={isLoading} />

          {isSuccess && (
            <>
              <input
                type="text"
                id="filter-value"
                class="form-control"
                placeholder="search student"
                name="name"
                onKeyUp={updateFilter}
              />

              <button
                className=" mt-2 btn btn-primary btn-sm"
                onClick={() => table.download("csv", "student.csv")}
              >
                Download CSV FILE
              </button>

              <div className="" id="table" />
            </>
          )}
        </div>
      </section>
    </div>
  );
}

export default memo(AllStudent);
