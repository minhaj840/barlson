import React, { memo, useEffect, useState } from "react";
import { FcEmptyTrash, FcEditImage } from "react-icons/fc";
import { useMutation } from "react-query";
import { useQueryClient } from "react-query";
import {
  deleteStudent,
  updateStudentStatus,
} from "../../services/dashboad/dash";
import Loader from "../../utils/loader/Loader";
import { toastApiError } from "../../utils/toast/toast";
import ProfileModel from "../../model/ProfileModel";
import Swal from "sweetalert2";
function StudentCard({ student }) {


  const queryClient = useQueryClient();

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);

  // update certificate issues
  const mutation = useMutation((id) => updateStudentStatus(id), {
    onSuccess: () => {
      queryClient.invalidateQueries("student");
    },
  });
  const mutationDelete = useMutation((id) => deleteStudent(id), {
    onSuccess: () => {
      queryClient.invalidateQueries("student");
    },
  });

  if (mutation.isError) {
    toastApiError(mutation.error);
  }
  if (mutationDelete.isError) {
    toastApiError(mutationDelete.error);
  }

  useEffect(() => {
    if (mutationDelete.isSuccess || mutation.isSuccess) {
      // window.location.reload();
    }
  }, [mutationDelete.isSuccess, mutation.isSuccess]);

  // CONFIRM BOX
  const ConfirmBox = () => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      // confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        mutationDelete.mutate(student.studentID);
        Swal.close()
        // Swal.fire("Deleted!", "Student has been deleted.", "success");
      }
    });
  };

  //mutationDelete.mutate(student.studentID)
  return (
    <>
      <ProfileModel
        show={show}
        handleClose={handleClose}
        data={student}
        key={student}
      />
      <Loader loader={mutation.isLoading} />
      <Loader loader={mutationDelete.isLoading} />

      <div className="col-xl-12 mb-2 col-lg-12 col-md-12 col-12">
        <div className="card">
          <div className="card-body">
            <div className="d-flex align-items-center justify-content-between mb-0 lh-0">
              <div className="d-flex gap-3">
                <span className="fs-6 text-danger text-uppercase fw-semibold">
                  {student?.internRole}
                </span>
                <span className="fs-6 text-danger text-uppercase fw-semibold">
                  <button
                    className="btn mx-4 btn-danger btn-sm"
                    disabled={student.isCourseCompleted ? true : false}
                    style={{
                      background: student.isCourseCompleted ? "green" : "red",
                    }}
                    onClick={() => mutation.mutate(student.studentID)}
                  >
                    issues certificate
                  </button>
                </span>
              </div>
              <div className="d-flex gap-3">
                <div
                  className="actionIcons fs-5 text-danger"
                  onClick={() => ConfirmBox()}
                >
                  <FcEmptyTrash size={20} />
                </div>
                <div
                  className="actionIcons fs-5 text-danger"
                  onClick={() => setShow(true)}
                >
                  <FcEditImage size={20} />
                </div>
              </div>
            </div>
            <h2 className="fw-bold mb-0">{student?.name}</h2>
            <span className="text-success fw-semibold">
              <i className="fe fe-trending-up me-1"></i>Student Id : #{" "}
              {student?.studentID}
            </span>{" "}
            ♨
            <span className="text-success fw-semibold">
              <i className="fe fe-trending-up me-1"></i>Duration :{" "}
              {student?.duration}
            </span>
          </div>
        </div>
      </div>
    </>
  );
}

export default memo(StudentCard);
