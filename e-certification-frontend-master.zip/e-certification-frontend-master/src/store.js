import { configureStore } from "@reduxjs/toolkit";
import toggleMenuReducer  from "./redux/globalApiSlice";

export const store = configureStore({
  reducer: {
    toggleMenu: toggleMenuReducer,
  },
});
