import moment from "moment";
import { memo } from "react";
import { Form } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";

function ProfileModel(props) {
  const show = props.show;
  const handleClose = props.handleClose;
  const data = props.data;

  //  start date
  const date = moment(data?.startDate);
  const formattedStartDate = date.format("DD MMM YYYY");

  // get end date
  const formatedStartDateCal = moment(data?.startDate);
  const match = data?.duration.match(/\d+/);
  const durationMonths = parseInt(match[0], 10);
  const FendDate = formatedStartDateCal.clone().add(durationMonths, "months");
  const formattedEndDate = FendDate.format("DD MMM YYYY");

  return (
    <>
      <Modal
        show={show}
        onHide={handleClose}
        animation={true}
        // backdrop="static"
        // keyboard={false}
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>Student Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="row">
            <div className="col-lg-12">
              <Form>
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Label>Name</Form.Label>
                  <Form.Control type="text" value={data?.name} />
                </Form.Group>
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Label>studentID</Form.Label>
                  <Form.Control type="text" value={data?.studentID} />
                </Form.Group>
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Label>Email</Form.Label>
                  <Form.Control type="text" value={data?.email} />
                </Form.Group>
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Label>Duration</Form.Label>
                  <Form.Control type="text" value={data?.duration} />
                </Form.Group>
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Label>InternRole</Form.Label>
                  <Form.Control type="text" value={data?.internRole} />
                </Form.Group>
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Label>Start Date</Form.Label>
                  <Form.Control type="text" value={formattedStartDate} />
                </Form.Group>
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Label>End Date</Form.Label>
                  <Form.Control type="text" value={formattedEndDate} />
                </Form.Group>
              </Form>
            </div>
            <div className="col-lg-5">
              <div>
                <object
                  width="100%"
                  data={data?.certificate}
                  type="application/pdf"
                  aria-label="Pdf"
                />
              </div>
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default memo(ProfileModel);
