import { useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { Axios } from "../services/axios";
import { toastApiError, toastError, toastSuccess } from "../utils/toast/toast";

function AdminRegisterModel({ show, handleClose }) {
  const [admin, setAdmin] = useState({
    email: "",
    password: "",
    roles: "admin",
  });
  const [isLoading, setIsLoading] = useState(false);

  // onchange
  const handleChangetext = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setAdmin({ ...admin, [name]: value });
  };

  // handle submit
  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    const { email, password } = admin;
    try {
      if (!email) {
        toastError("Email is required!");
      } else if (!password) {
        toastError("Password is required!");
      } else {
        // do signin
        const resp = await Axios.post("/auth/login", admin);

        if (resp?.status === 201) {
          toastSuccess("admin login  successfully");
          if (resp?.data) {
            localStorage.setItem(
              "AdminAuthInt",
              JSON.stringify({ token: resp?.data?.token, data: resp?.data })
            );
            setTimeout(() => {
              window.location.reload();
            }, 2000);
          } else {
            toastError("Unauthorized");
          }
        } else {
          toastError(resp?.data?.message);
        }
      }
    } catch (error) {
      toastApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Modal
        show={show}
        onHide={handleClose}
        animation={false}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Admin Login</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form className=" rounded border-1 p-3">
            <div class="mb-3">
              <label class="form-label" for="textInput">
                Email
              </label>
              <input
                type="email"
                id="textInput"
                class="form-control"
                placeholder="Enter registered email"
                name="email"
                value={admin.email}
                onChange={(e) => handleChangetext(e)}
              />
            </div>
            <div class="mb-3">
              <label class="form-label" for="textInput">
                Password
              </label>
              <input
                type="text"
                id="textInput"
                class="form-control"
                placeholder="Enter registered email"
                name="password"
                value={admin.password}
                onChange={(e) => handleChangetext(e)}
              />
            </div>
          </form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button
            variant="primary"
            disabled={isLoading}
            onClick={(e) => handleLogin(e)}
          >
            Admin Login
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default AdminRegisterModel;
