import { useEffect, useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { toastApiError } from "../utils/toast/toast";
import { getAllStudent } from "../services/auth/auth";
import { useMutation, useQuery, useQueryClient } from "react-query";
import Loader from "../utils/loader/Loader";
import { FcEditImage, FcEmptyTrash } from "react-icons/fc";
import ProfileModel from "./ProfileModel";
import { Col, Row } from "react-bootstrap";
import { deleteStudent, updateStudentStatus } from "../services/dashboad/dash";
import Swal from "sweetalert2";

function AllStudentModel({ show, handleClose }) {
  //get all student
  const queryClient = useQueryClient();
  const [student1, setStudent1] = useState([]);
  const [pending, setPending] = useState([]);
  const [issues, setIssues] = useState([]);

  const { isLoading, isSuccess, isError, error, data } = useQuery(
    "student",
    getAllStudent
  );

  if (isError) {
    toastApiError(error);
  }

  const [show1, setShow1] = useState(false);

  const handleClose1 = () => setShow1(false);

  // update certificate issues
  const mutation = useMutation((id) => updateStudentStatus(id), {
    onSuccess: () => {
      queryClient.invalidateQueries("student");
    },
  });
  const mutationDelete = useMutation((id) => deleteStudent(id), {
    onSuccess: () => {
      queryClient.invalidateQueries("student");
    },
  });

  if (mutation.isError) {
    toastApiError(mutation.error);
  }
  if (mutationDelete.isError) {
    toastApiError(mutationDelete.error);
  }

  useEffect(() => {
    if (mutationDelete.isSuccess || mutation.isSuccess) {
      window.location.reload();
    }
  }, [mutationDelete.isSuccess, mutation.isSuccess]);

  // CONFIRM BOX
  const ConfirmBox = (id) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        mutationDelete.mutate(id);
        Swal.fire("Deleted!", "Student has been deleted.", "success");
      }
    });
  };

  const handleStudentShowModel = (student) => {
    setStudent1(student);
  };


    // handleSearch
    const handleSearch = (e) => {
        const value = e.target.value;
        if (value) {
          const filterData = data?.data?.data?.filter((stud) => {
            return stud.name.toLowerCase().includes(value.toLowerCase());
          });
        //   setStudentData(filterData);
          setPending(filterData);
          setIssues(filterData);
        } else {
        //   setStudentData(data?.data?.data);
        setPending(
            data?.data?.data?.filter((stud) => stud.isCourseCompleted === false)
          );
          setIssues(
            data?.data?.data?.filter((stud) => stud.isCourseCompleted === true)
          );
        }
      };


  useEffect(() => {
    if (isSuccess) {
      setPending(
        data?.data?.data?.filter((stud) => stud.isCourseCompleted === false)
      );
      setIssues(
        data?.data?.data?.filter((stud) => stud.isCourseCompleted === true)
      );
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSuccess]);

  return (
    <>
      {show1 && (
        <ProfileModel
          show={show1}
          handleClose={handleClose1}
          data={student1}
          key={student1}
        />
      )}

      <Modal
        show={show}
        onHide={handleClose}
        centered
        keyboard={false}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
      >
        <Modal.Header closeButton>
          <Modal.Title>
            All Students
            <div className="mt-2 textSearch">
              <input
                type="text"
                id="textInput"
                className="w-full form-control searchContro1l"
                placeholder="Search student"
                onChange={handleSearch}
              />
            </div>
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Loader loader={isLoading} />

          {isSuccess && (
            <>
              <ul
                class="nav nav-tabs nav-justified mb-3"
                id="ex1"
                role="tablist"
              >
                <li class="nav-item" role="presentation">
                  <a
                    class="nav-link"
                    id="ex3-tab-2"
                    data-bs-toggle="tab"
                    href="#ex3-tabs-2"
                    role="tab"
                    aria-controls="ex3-tabs-2"
                    aria-selected="false"
                  >
                    PENDING ISSUES CERTIFICATE
                  </a>
                </li>
                <li class="nav-item" role="presentation">
                  <a
                    class="nav-link"
                    id="ex3-tab-3"
                    data-bs-toggle="tab"
                    href="#ex3-tabs-3"
                    role="tab"
                    aria-controls="ex3-tabs-3"
                    aria-selected="false"
                  >
                    ISSUES CERTIFICATE{" "}
                  </a>
                </li>
              </ul>

              <div class="tab-content" id="ex2-content">
                <div
                  class="tab-pane fade"
                  id="ex3-tabs-2"
                  role="tabpanel"
                  aria-labelledby="ex3-tab-2"
                >
                  <Row>
                    <Col lg={12}>
                      {pending?.map((student) => {
                        return (
                          <div className="col-xl-12 mb-2 col-lg-12 col-md-12 col-12">
                            <div className="card">
                              <div className="card-body">
                                <div className="d-flex align-items-center justify-content-between mb-0 lh-0">
                                  <div className="d-flex gap-3">
                                    <span className="fs-6 text-danger text-uppercase fw-semibold">
                                      {student?.internRole}
                                    </span>
                                    <span className="fs-6 text-danger text-uppercase fw-semibold">
                                      <button
                                        className="btn mx-4 btn-danger btn-sm"
                                        disabled={
                                          student.isCourseCompleted
                                            ? true
                                            : false
                                        }
                                        style={{
                                          background: student.isCourseCompleted
                                            ? "green"
                                            : "red",
                                        }}
                                        onClick={() =>
                                          mutation.mutate(student.studentID)
                                        }
                                      >
                                        issues certificate
                                      </button>
                                    </span>
                                  </div>
                                  <div className="d-flex gap-3">
                                    <div
                                      className="actionIcons fs-5 text-danger"
                                      onClick={() => ConfirmBox(student?.studentID)}
                                    >
                                      <FcEmptyTrash size={20} />
                                    </div>
                                    <div
                                      className="actionIcons fs-5 text-danger"
                                      onClick={() => {
                                        handleStudentShowModel(student);
                                        setShow1(true);
                                      }}
                                    >
                                      <FcEditImage size={20} />
                                    </div>
                                  </div>
                                </div>
                                <h2 className="fw-bold mb-0">
                                  {student?.name}
                                </h2>
                                <span className="text-success fw-semibold">
                                  <i className="fe fe-trending-up me-1"></i>
                                  Student Id : # {student?.studentID}
                                </span>{" "}
                                ♨
                                <span className="text-success fw-semibold">
                                  <i className="fe fe-trending-up me-1"></i>
                                  Duration : {student?.duration}
                                </span>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </Col>
                  </Row>
                </div>
                <div
                  class="tab-pane fade"
                  id="ex3-tabs-3"
                  role="tabpanel"
                  aria-labelledby="ex3-tab-3"
                >
                  <Row>
                    <Col lg={12}>
                      {issues?.map((student) => {
                        return (
                          <div className="col-xl-12 mb-2 col-lg-12 col-md-12 col-12">
                            <div className="card">
                              <div className="card-body">
                                <div className="d-flex align-items-center justify-content-between mb-0 lh-0">
                                  <div className="d-flex gap-3">
                                    <span className="fs-6 text-danger text-uppercase fw-semibold">
                                      {student?.internRole}
                                    </span>
                                    <span className="fs-6 text-danger text-uppercase fw-semibold">
                                      <button
                                        className="btn mx-4 btn-danger btn-sm"
                                        disabled={
                                          student.isCourseCompleted
                                            ? true
                                            : false
                                        }
                                        style={{
                                          background: student.isCourseCompleted
                                            ? "green"
                                            : "red",
                                        }}
                                        onClick={() =>
                                          mutation.mutate(student.studentID)
                                        }
                                      >
                                        issues certificate
                                      </button>
                                    </span>
                                  </div>
                                  <div className="d-flex gap-3">
                                    <div
                                      className="actionIcons fs-5 text-danger"
                                      onClick={() => ConfirmBox(student?.studentID)}
                                    >
                                      <FcEmptyTrash size={20} />
                                    </div>
                                    <div
                                      className="actionIcons fs-5 text-danger"
                                      onClick={() => {
                                        handleStudentShowModel(student);
                                        setShow1(true);
                                      }}
                                    >
                                      <FcEditImage size={20} />
                                    </div>
                                  </div>
                                </div>
                                <h2 className="fw-bold mb-0">
                                  {student?.name}
                                </h2>
                                <span className="text-success fw-semibold">
                                  <i className="fe fe-trending-up me-1"></i>
                                  Student Id : # {student?.studentID}
                                </span>{" "}
                                ♨
                                <span className="text-success fw-semibold">
                                  <i className="fe fe-trending-up me-1"></i>
                                  Duration : {student?.duration}
                                </span>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </Col>
                  </Row>
                </div>
              </div>
            </>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default AllStudentModel;
