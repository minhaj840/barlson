import React, { lazy, memo, Suspense } from "react";
import "./App.css";
import { Routes, Route } from "react-router-dom";

// import Header from "./components/Header";
// import HomePage from "./page/HomePage";
// import Login from "./components/auth/Login";
// import ProfilePage from "./page/ProfilePage";
// import NotFound from "./components/NotFound";
// import Ambassdor from "./components/ambassdor/Ambassdor";
// import AdminDashboard from "./components/dashboad/adminDashboard";

import { Protected } from "./utils/Protected";
import Loading from "./components/Loading";
import HackthonPage from "./components/hackthonTest/index";

// add lazy loading
const Header = lazy(() => import("./components/Header"));
const HomePage = lazy(() => import("./page/HomePage"));
const Login = lazy(() => import("./components/auth/Login"));
const ProfilePage = lazy(() => import("./page/ProfilePage"));
const NotFound = lazy(() => import("./components/NotFound"));

const Ambassdor = lazy(() => import("./components/ambassdor/Ambassdor"));

const Certification = lazy(() =>
  import("./components/certificationPart/Certification")
);

const AdminDashboard = lazy(() =>
  import("./components/dashboad/adminDashboard")
);

function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route
          path="/"
          element={
            <Suspense fallback={<Loading />}>
              <HomePage />
            </Suspense>
          }
        />
        <Route
          path="/login"
          element={
            <Suspense fallback={<Loading />}>
              <Login />
            </Suspense>
          }
        />
        <Route
          path="/ambassdor"
          element={
            <Suspense fallback={<Loading />}>
              <Ambassdor />
            </Suspense>
          }
        />
        <Route
          path="/certification"
          element={
            <Suspense fallback={<Loading />}>
              <Certification />
            </Suspense>
          }
        />
        <Route exact path="/" element={<Protected />}>
          <Route
            path="/student/profile/"
            element={
              <Suspense fallback={<Loading />}>
                <ProfilePage />
              </Suspense>
            }
          />
        </Route>

        {/**Admin Protected */}
        <Route>
          <Route
            path="/student/register/*"
            element={
              <Suspense fallback={<Loading />}>
                <AdminDashboard />
              </Suspense>
            }
          />
        </Route>

        {/**hackthon Protected */}
        {/**  <Route>
          <Route
            path="/hackthon/student/*"
            element={
              <Suspense fallback={<Loading />}>
                <HackthonPage />
              </Suspense>
            }
          />
        </Route> */}

        <Route
          path="*"
          element={
            <Suspense fallback={<Loading />}>
              <NotFound />
            </Suspense>
          }
        />
      </Routes>
    </>
  );
}

export default memo(App);
