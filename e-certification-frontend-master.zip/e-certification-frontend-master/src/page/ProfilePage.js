import React, { memo } from "react";
import Banner from "../components/profile/Banner";

function ProfilePage() {
  return (
    <div className="profile-section container ">
      <Banner />
    </div>
  );
}

export default memo(ProfilePage);
