import React, { memo } from "react";
import Home from "../components/home/Home";

function HomePage() {
  return (
    <div className="wrapper section">
      <div className="container">
        <Home />
      </div>
    </div>
  );
}

export default memo(HomePage);
