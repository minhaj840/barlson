const dotenv = require("dotenv");
dotenv.config({});
require("./config/connection");

const express = require("express");
const cors = require("cors");
const AuthUserServices = require("./controllers/student.controller");
const studentRouter = require("./routes/student.routes");
const { Admins } = require("./models/Admin");
const fileUpload = require("express-fileupload");
const ambassdorRouter = require("./routes/ambassdor.routes");
const hackthonRouter = require("./routes/hackthon.routes");
const path = require("path");
const sendEmailToStudent = require("./utils/email/sendEmailToStudent");
const questionRouter = require("./routes/question.routes");
const hackTestRouter = require("./routes/hackTest.routes");

// App
const app = express();

// middleware
app.use(express.static(path.join(__dirname + "/public")));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const PORT = process.env.PORT || 5000;
// cors
const corsOptions = {
  origin: "*",
  credentials: true, //access-control-allow-credentials:true
  optionSuccessStatus: 200,
};

app.use(cors(corsOptions));
module.exports = userModel = (req, res, next) => {
  req.model = Admins;
  next();
};

// app.use(
//   fileUpload({
//     useTempFiles: true,
//     tempFileDir: "/temp",
//   })
// );

app.get("/", (req, res) => {
  res.json("Server is Running ");
});

app.use("/api/question", questionRouter);
app.use("/api/hackTest", hackTestRouter);

// add student
app.use("/api", studentRouter);

app.post("/api/sendMail", sendEmailToStudent);

// only here multer add
app.use("/api", hackthonRouter);

app.use(
  "/api/ambassdor",
  fileUpload({
    useTempFiles: true,
    tempFileDir: "/tmp",
  }),
  ambassdorRouter
);

// auth
app.post("/api/auth/register", userModel, AuthUserServices.register);
app.post("/api/auth/login", userModel, AuthUserServices.login);

// listem
app.listen(PORT, async () => {
  console.log("app is running on port " + PORT);
});

// const runDb = async () => {
//   try {
//     const DB =
//       "mongodb+srv://db:6O3rHBpJYYLnGjbV@database.l2fnk.mongodb.net/certifications?retryWrites=true&w=majority";
//     // process.env.NODE_ENV !== "production"
//     //   ? process.env.MONGO_CONNECTION_STRING
//     //   : process.env.MONGO_CONNECTION_STRING_DEV;

//     mongoose.set("strictQuery", false);
//     await mongoose.connect(DB, { useUnifiedTopology: false });
//     console.log("connected to MongoDB");

//     app.listen(PORT, async () => {
//       console.log("app is running on port " + PORT);
//     });
//   } catch (error) {
//     console.log("connection error " + error);
//   }
// };
// runDb();

module.exports = app;
