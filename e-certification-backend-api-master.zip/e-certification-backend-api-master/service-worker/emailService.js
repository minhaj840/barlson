// import { Worker } from "bullmq";
// const IORedis  = require("ioredis")

// const connection = new IORedis();

// const worker = new Worker("Email", async (job) => {
//   try {
//     console.log(job);

//   } catch (error) {
//     console.error('error painting', error);

//   }
// },{ connection }).run();
