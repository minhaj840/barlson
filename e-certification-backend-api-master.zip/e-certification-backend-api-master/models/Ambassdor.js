const mongoose = require("mongoose");

const AmbassdorSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: ["email is required", true],
    },
    collgeName: {
      type: String,
      required: true,
    },
    profile: {
      type: String,
    },
    contact:{
      type: String,
    },
    ID: {
      type: String,
    },
    isIssued: {
      type: Boolean,
      enum: [true, false],
      default: false,
    },
    startDate: {
      type: Date,
      required: false,
      default: new Date(),
    },
  },
  {
    timestamps: true,
  }
);

const AmbassdorStudent = new mongoose.model(
  "AmbassdorStudent",
  AmbassdorSchema
);

module.exports = { AmbassdorStudent };
