const mongoose = require("mongoose");

const hackStudents = new mongoose.Schema(
  {
    email: {
      type: String,
    },
    name: {
      type: String,
    },
    graduationComplete: {
      type: String,
    },
    collegeName: {
      type: String,
    },
    stream: {
      type: String,
    },
    contact: {
      type: String,
    },
    is_completed_test: {
      type: Boolean,
      default: false,
      enum: [true, false],
    },
    question: [
      {
        title: {
          type: String,
        },
        description: {
          type: String,
        },
        category: {
          type: String,
        },
      },
    ],
    answers: [],
  },
  {
    strict: true,
    timestamps: true,
  }
);
const hackTest = mongoose.model("hackTests", hackStudents);
module.exports = hackTest;
