const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const studentSchema = new mongoose.Schema(
  {
    studentID: {
      type: String,
      required: false,
    },
    name: {
      type: String,
    },
    email: {
      type: String,
      required: ["email is required", true],
    },

    certificate: {
      type: String,
      default: "",
      required: false,
    },
    isCourseCompleted: {
      type: Boolean,
      default: false,
      required: false,
    },
    internRole: {
      type: String,
      required: true,
    },
    duration: {
      type: String,
      required: true,
    },
    startDate: {
      type: Date,
      required: false,
      default: new Date(),
    },
    endDate: {
      type: Date,
      required: false,
      default: "",
    },
    adminId:{
      type: mongoose.Schema.ObjectId,
      path: 'Admins',
      required: true,
    }
  },
  {
    timestamps: true,
  }
);

const Students = new mongoose.model("Students", studentSchema);

module.exports = { Students };
