const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const adminSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: ["email is required", true],
    },

    password: {
      type: String,
      required: ["password is required", true],
    },

    roles: {
      type: String,
      enum: ["admin", "student"],
      default: "admin",
    },
  },
  {
    timestamps: true,
  }
);

// // middle ware
// adminSchema.pre("save", async function (next) {
//   if (this.isModified("password")) {
//     this.password = await bcrypt.hash(this.password, 12);
//   }
//   next();
// });

adminSchema.methods.checkPassword = function (password) {
  const passwordHash = this.password;
  return new Promise((resolve, reject) => {
    bcrypt.compare(password, passwordHash, (err, same) => {
      if (err) {
        return reject(err);
      }
      resolve(same);
    });
  });
};

const Admins = new mongoose.model("Admins", adminSchema);

module.exports = { Admins };
