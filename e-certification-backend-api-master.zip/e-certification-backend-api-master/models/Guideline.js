const mongoose = require("mongoose");

const guidelineSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
});
const Guideline = mongoose.model("Guideline", guidelineSchema);
module.exports = Guideline;
