const mongoose = require("mongoose");


// listem
const runDb = async () => {
    try {
      const DB =
        "mongodb+srv://db:6O3rHBpJYYLnGjbV@database.l2fnk.mongodb.net/certifications?retryWrites=true&w=majority";
      mongoose.set("strictQuery", false);
      await mongoose.connect(DB, { useUnifiedTopology: false });
      console.log("connected to MongoDB");
    } catch (error) {
      console.log("connection error " + error);
    }
  };
  runDb();