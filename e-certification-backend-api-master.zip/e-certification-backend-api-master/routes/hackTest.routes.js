// AuthStudentAmbassdorServices
const express = require("express");
const { Admins } = require("../models/Admin");
const { checkUserAuth } = require("../utils/jwt");
const AuthHackTestServices = require("../controllers/hackTest.controller");
const hackTest = require("../models/HackTest");
const Guideline = require("../models/Guideline");

// Create a new router object
const hackTestRouter = express.Router();

module.exports = adminModel = (req, res, next) => {
  req.model = Admins;
  next();
};

module.exports = hackTestModel = (req, res, next) => {
  req.model = hackTest;
  next();
};
module.exports = guidelineModel = (req, res, next) => {
  req.model = Guideline;
  next();
};

// upload by admin csv file of student
hackTestRouter.post(
  "/csv",
  adminModel,
  checkUserAuth,
  hackTestModel,
  AuthHackTestServices.uploadFile
);

// add guidline
hackTestRouter.post(
  "/guideline",
  adminModel,
  checkUserAuth,
  guidelineModel,
  AuthHackTestServices.addGuideline
);
hackTestRouter.get(
  "/guideline",
  guidelineModel,
  AuthHackTestServices.getGuideline
);

// get all student
hackTestRouter.get(
  "/allStudent",
  adminModel,
  checkUserAuth,
  hackTestModel,
  AuthHackTestServices.allStudent
);
hackTestRouter.get(
  "/allStudentCompletedTest",
  adminModel,
  checkUserAuth,
  hackTestModel,
  AuthHackTestServices.allStudentCompletedTest
);

// merge question to student
hackTestRouter.get(
  "/merge/question",
  adminModel,
  checkUserAuth,
  hackTestModel,
  AuthHackTestServices.distributeQuestionToStudent
);

// login student using email
hackTestRouter.post("/login", hackTestModel, AuthHackTestServices.login);

//submit anseers
hackTestRouter.post(
  "/submitAnswer",
  hackTestModel,
  checkUserAuth,
  AuthHackTestServices.submitAnswer
);
//get userby id token
hackTestRouter.get(
  "/getQuestion",
  hackTestModel,
  checkUserAuth,
  AuthHackTestServices.getQuestion
);

hackTestRouter.get(
  "/completeTest",
  hackTestModel,
  checkUserAuth,
  AuthHackTestServices.completeTest
);

hackTestRouter.get(
  "/getStatusTest",
  hackTestModel,
  checkUserAuth,
  AuthHackTestServices.getStatusTest
);

module.exports = hackTestRouter;
