// AuthStudentAmbassdorServices
const express = require("express");
const { Admins } = require("../models/Admin");
const { checkUserAuth } = require("../utils/jwt");
const { Hackthons } = require("../models/Hackthon");
const AuthStudentHackthonServices = require("../controllers/hackthon.controller");

// Create a new router object
const hackthonRouter = express.Router();

module.exports = adminModel = (req, res, next) => {
  req.model = Admins;
  next();
};
module.exports = hackModel = (req, res, next) => {
  req.model = Hackthons;
  next();
};

hackthonRouter.post(
  "/hackthon/csv",
  adminModel,
  checkUserAuth,
  hackModel,
  AuthStudentHackthonServices.uploadFile
);

hackthonRouter.get(
  "/hackthon/all",
  adminModel,
  checkUserAuth,
  hackModel,
  AuthStudentHackthonServices.getAllHackthon
);

hackthonRouter.post(
  "/hackthon/login",
  hackModel,
  AuthStudentHackthonServices.getHackthonProfile
);

module.exports = hackthonRouter;
