// AuthStudentAmbassdorServices
const express = require("express");
const { Admins } = require("../models/Admin");
const AuthStudentAmbassdorServices = require("../controllers/ambasdor.controller");
const { AmbassdorStudent } = require("../models/Ambassdor");
const { checkUserAuth } = require("../utils/jwt");

// Create a new router object
const ambassdorRouter = express.Router();

module.exports = adminModel = (req, res, next) => {
  req.model = Admins;
  next();
};
module.exports = ambassdorModel = (req, res, next) => {
  req.model = AmbassdorStudent;
  next();
};
ambassdorRouter.post(
  "/register",
  ambassdorModel,
  AuthStudentAmbassdorServices.register
);
ambassdorRouter.post(
  "/login",
  ambassdorModel,

  AuthStudentAmbassdorServices.login
);

ambassdorRouter.get(
  "/getAll",
  adminModel,
  checkUserAuth,
  ambassdorModel,
  AuthStudentAmbassdorServices.getAllAmbassador
);

ambassdorRouter.delete(
  "/delete/:id",
  adminModel,
  checkUserAuth,
  ambassdorModel,
  AuthStudentAmbassdorServices.deleteAmbassador
);

ambassdorRouter.get(
  "/status/:id",
  adminModel,
  checkUserAuth,
  ambassdorModel,
  AuthStudentAmbassdorServices.getAmbassadorProfileUpdate
);

ambassdorRouter.get(
  "/profile/:id",
  ambassdorModel,
  AuthStudentAmbassdorServices.getAmbassadorProfile
);

module.exports = ambassdorRouter;
