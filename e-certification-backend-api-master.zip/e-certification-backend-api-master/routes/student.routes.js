const express = require("express");
const AuthUserServices = require("../controllers/student.controller");
const { isAdmin } = require("../utils/isUserAdmin");
const { checkUserAuth } = require("../utils/jwt");
const { Admins } = require("../models/Admin");
const { Students } = require("../models/Student");

// Create a new router object
const studentRouter = express.Router();

module.exports = adminModel = (req, res, next) => {
  req.model = Admins;
  next();
};
module.exports = userModel = (req, res, next) => {
  req.model = Students;
  next();
};
studentRouter.post(
  "/student/add",
  adminModel,
  checkUserAuth,
  isAdmin,
  AuthUserServices.addStudent
);


studentRouter.delete(
  "/student/delete/:studentID",
  adminModel,
  checkUserAuth,
  isAdmin,
  AuthUserServices.deleteStudent
);


studentRouter.get(
  "/student/getAll",
  adminModel,
  checkUserAuth,
  AuthUserServices.getAllStudents
);

studentRouter.get(
  "/student/update/status/:id",
  adminModel,
  checkUserAuth,
  isAdmin,
  AuthUserServices.getStudentProfileUpdate
);


// for student controlled 

studentRouter.post("/student/login", userModel, AuthUserServices.studentLogin);


studentRouter.get(
  "/student/profile/:id",
  userModel,
  checkUserAuth,
  AuthUserServices.getStudentProfile
);

module.exports = studentRouter;
