const express = require("express");
const AuthUserServices = require("../controllers/student.controller");
const { isAdmin } = require("../utils/isUserAdmin");
const { checkUserAuth } = require("../utils/jwt");
const { Admins } = require("../models/Admin");
const question = require("../models/question");
const HackQuestionServices = require("../controllers/question.controller");

// Create a new router object
const questionRouter = express.Router();

module.exports = adminModel = (req, res, next) => {
  req.model = Admins;
  next();
};
module.exports = questionModel = (req, res, next) => {
  req.model = question;
  next();
};

questionRouter.post(
  "/add",
  adminModel,
  checkUserAuth,
  isAdmin,
  questionModel,
  HackQuestionServices.addQuestion
);

questionRouter.delete(
  "/delete/:questionID",
  adminModel,
  checkUserAuth,
  isAdmin,
  questionModel,
  HackQuestionServices.deleteQuestions
);

questionRouter.get(
  "/getAll",
  adminModel,
  checkUserAuth,
  isAdmin,
  questionModel,
  HackQuestionServices.getAllQuestion
);

module.exports = questionRouter;
