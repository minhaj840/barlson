class AuthStudentHackthonServices {
  static uploadFile = async (req, res) => {
    const Model = req.model;

    if (!req.body.data) {
      return res.status(401).send({
        message: "csv data missing",
      });
    } else {
      try {
        const mapData = req.body.data?.map((stud, index) => {
          const des = req.body?.data[index];
          const email = des["Email"];
          const name = des["Full Name"];
          const contact = des["Contact No."];
          const collegeName = des["College Name"];
          const graduationComplete = des["Graduation completion year"];
          const stream = des["Stream"];
          return {
            email,
            name,
            contact,
            graduationComplete,
            collegeName,
            stream,
          };
        });
        mapData?.forEach(async (item) => {
          const exist = await Model.findOne({ email: item.email });
          if (!exist) {
            await Model.create(item);
            // const insertData = await Model.insertMany(dupData);
          }
          // return !exist ? item : [];
        });

        // const dupDataProm = await dupData;
        // console.log(dupDataProm);

        // const insertData = await Model.insertMany(dupData);
        return res.status(201).send({ status: "ok" });
      } catch (e) {
        console.log(e);
        return res.status(500).send({ status: e.message });
      }
    }
  };

  // get all students
  static getAllHackthon = async (req, res) => {
    try {
      const Model = req.model;
      const student = await Model.find({});

      return res.status(200).send({ status: "ok", data: student });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting student error!",
      });
    }
  };

  // get profile
  static getHackthonProfile = async (req, res) => {
    try {
      const Model = req.model;
      const student = await Model.findOne({
        email: req.body.email,
      });
      if (student) {
        return res.status(200).send({ status: "ok", data: student });
      } else {
        return res.status(401).send({
          status: "failed",
          message: "You are not allowed to access!",
        });
      }
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: error?.message,
      });
    }
  };
}
module.exports = AuthStudentHackthonServices;
