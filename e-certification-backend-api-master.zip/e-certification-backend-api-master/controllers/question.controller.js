class HackQuestionServices {
  static addQuestion = async (req, res) => {
    const Model = req.model;
    const { title, description } = req.body;

    if (!title || !description) {
      return res.status(401).send({
        message: "some fields are missing",
      });
    } else {
      try {
        const insertData = await Model.create(req.body);
        return res.status(201).send({ status: "ok", data: insertData });
      } catch (e) {
        console.log(e);
        return res.status(500).send({ status: e.message });
      }
    }
  };

  // get all students
  static getAllQuestion = async (req, res) => {
    try {
      const Model = req.model;
      const student = await Model.find({});
      return res.status(200).send({ status: "ok", data: student });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting question error!",
      });
    }
  };

  // get profile
  static deleteQuestions = async (req, res) => {
    try {
      const Model = req.model;
      const del = await Model.findOneAndDelete({
        _id: req.params.questionID,
      });

      return res
        .status(201)
        .send({ status: "ok", message: "deleted successfully" });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "deleting question error!",
      });
    }
  };
}
module.exports = HackQuestionServices;
