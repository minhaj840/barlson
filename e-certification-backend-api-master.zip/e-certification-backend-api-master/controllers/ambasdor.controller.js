const { Model } = require("mongoose");
const { cloudinaryConfig } = require("../utils/cloudinary");
const { CAMID } = require("../utils/randomID");
const sendEmail = require("../utils/email/email");
// const { Queue } = require("bullmq");
// const IORedis  = require("ioredis")

let id = 0;
// const queue = new Queue("Email");
// const connection = new IORedis();
class AuthStudentAmbassdorServices {
  static register = async (req, res) => {
    const Model = req.model;
    if (
      !req.body.email ||
      !req.body.name ||
      !req.body.collgeName ||
      !req.files.profile ||
      !req.body.contact
    ) {
      return res.status(401).send({
        message: "Required fields missing",
      });
    }
    const user = await Model.findOne({ email: req.body.email });
    if (user)
      return res
        .status(401)
        .send({ status: "failed", message: "Email is already in use" });
    else {
      try {
        const campusData = {
          email: req.body.email,
          subject: "Welcome to the Campus Ambassador Program!",
          message: `Dear ${req.body.name},`,
          html: `
          We hope this email finds you well. We are excited to announce the launch of our Campus Ambassador Program at <b>BQARSON SOFTWARE TECHONOLOGIES PVT LTD</b>. As a dynamic and motivated student, we believe you have the potential to be an excellent ambassador for our brand on your college campus 
<b>${req.body.collgeName}.</b>

          `,
        };
        const adminData = {
          email: "ashif.ewp@gmail.com",
          subject: "New Campus Ambassador Registration",
          message: `Dear ${req.body.name} has registered as campus ambassador program,`,
          html: `
          Dear ${req.body.name} as successfully registered with email ${req.body.email} and college name <b>
          ${req.body.collgeName}
          </b>
          <br/>
          contact him if needed : <b>${req.body.contact}</b>
          `,
        };
        await sendEmail(campusData);
        await sendEmail(adminData);
        // const cap = await queue.add("email", campusData,{ connection }, {
        //   removeOnComplete: true,
        //   removeOnFail: true,
        // });
        // const adm = await queue.add("email", adminData,{ connection }, {
        //   removeOnComplete: true,
        //   removeOnFail: true,
        // });

        const ID = CAMID();
        var userData = req.body;
        const user = await Model.create(userData);
        // get profile image with cloudinary
        const result = await cloudinaryConfig(
          req.files.profile.tempFilePath,
          "image"
        );
        user.profile = result?.secure_url;
        await user.save();
        user.ID = ID;
        await user.save();
        return res.status(201).send({ status: "ok", data: user });
      } catch (e) {
        console.log(e);
        return res.status(500).send({ status: e.message });
      }
    }
  };
  static login = async (req, res) => {
    const Model = req.model;

    if (!req.body.email)
      return res.status(401).send({ message: "Email is required" });
    const user = await Model.findOne({
      email: req.body.email,
    }).exec();
    if (!user) {
      return res.status(401).send({
        status: "failed",
        message: "You are not allowed to access!",
      });
    }

    try {
      return res.status(201).send({ status: "ok", data: user });
    } catch (e) {
      console.error(e);
      return res.status(401).send({ message: "Not Authorized" });
    }
  };

  // delete student by their studentID
  static deleteAmbassador = async (req, res) => {
    try {
      const Model = req.model;

      const del = await Model.findOneAndDelete({
        _id: req.params.id,
      });

      return res
        .status(201)
        .send({ status: "ok", message: "deleted successfully" });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "adding student error!",
      });
    }
  };

  // update student profile
  static getAmbassadorProfileUpdate = async (req, res) => {
    try {
      const Model = req.model;

      const student = await Model.findOne({
        _id: req.params.id,
      });
      // send email 
      if (student.isIssued) {
        student.isIssued = false
      }
      else {
        student.isIssued = true

        const studentData = {
          email: student?.email,
          subject: "Your Campus Ambassador ID Successfully Issued!",
          message: `Dear ${student?.name} has registered as campus ambassador program,`,
          html: `
          Dear ${student?.name} as successfully registered with email ${student?.email} and college name <b>
          ${student?.collgeName}
          </b>
          <br/>
          <b>
           Go to website and download your Ambassador ID Cards 
          </b>
          
          `,
        };
        await sendEmail(studentData);


      }
      await student.save();





      return res.status(201).send({ status: "ok", data: student });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting student error!",
      });
    }
  };
  // get all students

  static getAllAmbassador = async (req, res) => {
    try {
      const Model = req.model;
      const student = await Model.find({});

      return res.status(200).send({ status: "ok", data: student });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting student error!",
      });
    }
  };

  // get profile
  static getAmbassadorProfile = async (req, res) => {
    try {
      const Model = req.model;

      const student = await Model.findOne({
        _id: req.params.id,
      });

      return res.status(201).send({ status: "ok", data: student });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting student error!",
      });
    }
  };
}
module.exports = AuthStudentAmbassdorServices;
