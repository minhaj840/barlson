const question = require("../models/question");
const { newToken } = require("../utils/jwt");

class AuthHackTestServices {
  static uploadFile = async (req, res) => {
    const Model = req.model;

    if (!req.body.data) {
      return res.status(401).send({
        message: "csv data missing",
      });
    } else {
      try {
        const mapData = req.body.data?.map((stud, index) => {
          const des = req.body?.data[index];
          const email = des["Email"];
          const name = des["Full Name"];
          const contact = des["Contact No."];
          const collegeName = des["College Name"];
          const graduationComplete = des["Graduation completion year"];
          const stream = des["Stream"];
          return {
            email,
            name,
            contact,
            graduationComplete,
            collegeName,
            stream,
          };
        });
        mapData?.forEach(async (item) => {
          const exist = await Model.findOne({ email: item.email });
          if (!exist) {
            await Model.create(item);
            // const insertData = await Model.insertMany(dupData);
          }
          // return !exist ? item : [];
        });

        // const dupDataProm = await dupData;
        // console.log(dupDataProm);

        // const insertData = await Model.insertMany(dupData);
        return res.status(201).send({ status: "ok" });
      } catch (e) {
        console.log(e);
        return res.status(500).send({ status: e.message });
      }
    }
  };

  // login student
  static login = async (req, res) => {
    const Model = req.model;
    console.log(req.body);
    try {
      if (!req.body.email)
        return res.status(401).send({ message: "Email is required" });
      const user = await Model.findOne({
        email: req.body.email,
      }).exec();
      if (!user) {
        return res.status(401).send({
          status: "failed",
          message: "You are not allowed to access!",
        });
      }

      const token = newToken(user);
      return res.status(201).send({ status: "ok", token: token, data: user });
    } catch (e) {
      console.error(e);
      return res.status(401).send({ message: "Not Authorized" });
    }
  };

  // get all student
  static allStudent = async (req, res) => {
    try {
      const Model = req.model;
      const student = await Model.find({});
      return res.status(200).send({ status: "ok", data: student });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting student error!",
      });
    }
  };
  static allStudentCompletedTest = async (req, res) => {
    try {
      const Model = req.model;
      const student = await Model.find({ is_completed_test: true });
      return res.status(200).send({ status: "ok", data: student });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting student error!",
      });
    }
  };

  static getQuestion = async (req, res) => {
    const Model = req.model;
    try {
      const userId = req.user.id;
      if (!userId) {
        return res.status(404).json({ message: "unauthorised users" });
      }
      const student = await Model.findOne({ _id: userId });
      return res.status(200).send({ status: "ok", data: student });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting student error!",
      });
    }
  };

  static getStatusTest = async (req, res) => {
    const Model = req.model;
    try {
      const userId = req.user.id;
      if (!userId) {
        return res.status(404).json({ message: "unauthorised users" });
      }
      const student = await Model.findOne({ _id: userId });
      return res
        .status(200)
        .send({ status: "ok", is_completed_test: student?.is_completed_test });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting student error!",
      });
    }
  };

  // add guideline
  static addGuideline = async (req, res) => {
    const Model = req.model;
    try {
      const userId = req.user.id;
      if (!userId) {
        return res.status(404).json({ message: "unauthorised users" });
      }
      const { name, description } = req.body;
      const existGuideline = await Model.findOne({ name: name });
      if (existGuideline) {
        existGuideline.description = description;
        await existGuideline.save();
        return res
          .status(200)
          .send({ status: "ok", message: "guideline created successfully" });
      } else {
        await Model.create({ name: name, description: description });
        return res
          .status(200)
          .send({ status: "ok", message: "guideline created successfully" });
      }
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting guideline error!",
      });
    }
  };

  static getGuideline = async (req, res) => {
    const Model = req.model;
    try {
      const data = await Model.findOne({ name: "guideline" });
      return res.status(200).send({ status: "ok", data: data });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting student error!",
      });
    }
  };

  // end

  // distribute question
  static distributeQuestionToStudent = async (req, res) => {
    try {
      const Model = req.model;
      // all students
      const student = await Model.find({});

      // all questions
      const questions = await question.find({});
      const len = questions.length;

      student.forEach(async (stud) => {
        // random question two
        // const ques1 = questions[Math.floor(Math.random() * len)];
        // const ques2 = questions[Math.floor(Math.random() * len)];

        // if (stud.length !== 0) {
        //   stud.question[0] = {
        //     title: ques1?.title,
        //     description: ques1?.description,
        //     questionId: ques1?._id,
        //   };
        //   stud.question[1] = {
        //     title: ques2?.title,
        //     description: ques2?.description,
        //     questionId: ques2?._id,
        //   };
        // } else {
        //   stud.question.push({
        //     title: ques1?.title,
        //     description: ques1?.description,
        //     questionId: ques1?._id,
        //   });
        //   stud.question.push({
        //     title: ques2?.title,
        //     description: ques2?.description,
        //     questionId: ques2?._id,
        //   });
        // }

        // await student.save();

        stud.question = questions;
        await stud.save();
      });

      // await student.save();

      return res.status(201).send({ status: "ok", data: student });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting student error!",
      });
    }
  };

  // submit answers

  // static submitAnswer = async (req, res) => {
  //   try {
  //     const Model = req.model;
  //     const userId = req.user.id;
  //     if (!userId) {
  //       return res.status(401).send({ message: "Not Authorized" });
  //     }
  //     const { questionId, github, website } = req.body;

  //     const student = await Model.findOne({ _id: req.user.id });

  //     const answerArray = student?.answers; //array

  //     //my code

  //     //end my code
  //     console.log(answerArray,"answerarray");
  //     if (answerArray.length !== 0) {
  //       // find questionId
  //       const exitAnswer = answerArray?.filter(
  //         (stud) => stud.questionId === questionId
  //       );
  //      console.log(exitAnswer,"exitAnwer")
  //       if (exitAnswer.length !== 0) {
  //         // exitAnswer[0].deployUrl = website;
  //         // exitAnswer[0].githubUrl = github;
  //        student.answers.forEach((ans)=>{
  //         if(ans.questionId===questionId)
  //         {
  //           ans.deployUrl=website;
  //           ans.githubUrl=github;
  //           console.log("cnage--->")
  //         }
  //        })
  //      console.log(ans.answers,"after achnge")
  //         // student.answers.push({
  //         //   questionId: questionId,
  //         //   deployUrl: website,
  //         //   githubUrl: github,
  //         // });

  //         await student.save();
  //       } else {
  //         student.answers.push({
  //           questionId: questionId,
  //           deployUrl: website,
  //           githubUrl: github,
  //         });
  //         await student.save();
  //       }
  //     } else {
  //       console.log(req.body);
  //       student.answers.push({
  //         questionId: questionId,
  //         deployUrl: website,
  //         githubUrl: github,
  //       });

  //       await student.save();
  //     }
  //     await student.save();

  //     return res.status(200).send({ status: "ok", data: student });
  //   } catch (error) {
  //     console.log(error);
  //     return res.status(401).send({
  //       status: "failed",
  //       message: "getting student error!",
  //     });
  //   }
  // };

  //
  static submitAnswer = async (req, res) => {
    try {
      const Model = req.model;
      const userId = req.user.id;
      if (!userId) {
        return res.status(401).send({ message: "Not Authorized" });
      }
      const { questionId, github, website } = req.body;

      const student = await Model.findOne({ _id: req.user.id });

      const answerArray = student?.answers; //array

      //my code
      const answerIndex = student.answers.findIndex(
        (ans) => ans.questionId === questionId
      );

      if (answerIndex !== -1) {
        // Update the existing answer
        student.answers[answerIndex].deployUrl = website;
        student.answers[answerIndex].githubUrl = github;
      } else {
        // Create a new answer object and push it to the answers array
        student.answers.push({
          questionId: questionId,
          deployUrl: website,
          githubUrl: github,
        });
      }

      // Save the student document
      await student.save();

      return res.status(200).send({ status: "ok", data: student });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting student error!",
      });
    }
  };
  //

  // get all students
  static completeTest = async (req, res) => {
    try {
      const Model = req.model;
      const userId = req.user.id;

      console.log(userId);

      if (!userId) {
        return res.status(401).send({ message: "Not Authorized" });
      }
      const student = await Model.findOne({
        _id: userId,
      });

      student.is_completed_test = true;
      await student.save();
      return res.status(200).send({ status: "ok", data: student });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting student error!",
      });
    }
  };
}
module.exports = AuthHackTestServices;
