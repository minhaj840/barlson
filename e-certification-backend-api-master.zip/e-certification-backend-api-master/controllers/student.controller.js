const bcrypt = require("bcryptjs");
const { newToken } = require("../utils/jwt");
const { Students } = require("../models/Student");

const lodash = require("lodash");

class AuthUserServices {
  static updatePassword = async (req, res) => {
    const Modal = req.model;
    const { newPassword } = req.body;
    if (!newPassword) {
      return res.status(400).json({ message: "Required fields missing" });
    }

    try {
      const hash = await bcrypt.hash(newPassword, 8);
      await Modal.findOneAndUpdate(
        req.user._id,
        { password: hash },
        { new: true }
      );

      res.status(200).send({
        status: "ok",
        message: "New password generated successfully",
      });
    } catch (error) {
      return res
        .status(500)
        .json({ status: "failed", message: "error.message" });
    }
  };
  static register = async (req, res) => {
    const Model = req.model;
    if (!req.body.email || !req.body.password || !req.body.roles) {
      return res.status(401).send({
        message: "Required fields missing",
      });
    }
    const user = await Model.findOne({ email: req.body.email });
    if (user)
      return res
        .status(401)
        .send({ status: "failed", message: "Email is already in use" });
    else {
      try {
        var userData = req.body;

        const hash = await bcrypt.hash(userData.password, 8);
        userData.password = hash;
        const user = await Model.create(userData);
        return res.status(201).send({ status: "ok", data: user });
      } catch (e) {
        console.log(e);
        return res.status(500).send({ status: e.message });
      }
    }
  };
  static login = async (req, res) => {
    const Model = req.model;

    if (!req.body.email || !req.body.password)
      return res.status(401).send({ message: "Email and password required" });
    const user = await Model.findOne({
      email: req.body.email,
      roles: req.body.roles,
    }).exec();
    if (!user) {
      return res.status(401).send({
        status: "failed",
        message: "You are not allowed to access!",
      });
    }

    try {
      const match = await user.checkPassword(req.body.password);

      if (!match) {
        return res
          .status(401)
          .send({ status: "failed", message: "Invalid Email or Password" });
      }

      const token = newToken(user);
      return res.status(201).send({ status: "ok", token: token, data: user });
    } catch (e) {
      console.error(e);
      return res.status(401).send({ message: "Not Authorized" });
    }
  };
  //   add student by admin
  static addStudent = async (req, res) => {
    try {
      const data = req.body;
      const adminId = req.user._id;


      //   check if student already exist
      const student = await Students.findOne({
        $or: [{ email: data?.email }, { studentID: data?.studentID }],
      });
      if (student) {
        return res
          .status(401)
          .send({ status: "failed", message: "Student already exist" });
      }
      // // add student to database
      const user = await Students.create({ ...data, adminId: adminId });


      const year = new Date().getFullYear();
      user.studentID = `${year}SE${Math.floor(Math.random() * 90000) + 10000}`;


      await user.save();



      const userPick = lodash.pick(user, [
        "name",
        "email",
        "isCourseCompleted",
        "internRole",
        "duration",
        "startDate",
        "studentID",
        "endDate",
      ]);

      return res.status(201).send({ status: "ok", data: userPick });


    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "adding student error!",
      });
    }
  };

  // delete student by their studentID
  static deleteStudent = async (req, res) => {
    try {

      const adminId = req.user._id;
      const del = await Students.findOneAndDelete({
        adminId: adminId,
        studentID: req.params.studentID,
      });

      if (del) {

        return res
          .status(201)
          .send({ status: "ok", message: "deleted successfully" });
      } else {


        return res
          .status(404)
          .send({ status: "error", message: "something error happend!" });
      }

    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "adding student error!",
      });
    }
  };

  //   student login
  static studentLogin = async (req, res) => {
    const user = await Students.findOne({
      $or: [
        {
          email: req.body.credential,
        },
        {
          studentID: req.body.credential,
        },
      ],
    }).exec();

    if (!user) {
      return res.status(401).send({
        status: "failed",
        message:
          "Your email not exist try with your registered email or student ID",
      });
    }
    try {
      const token = newToken(user);
      return res.status(201).send({ status: "ok", token: token, data: user });
    } catch (e) {
      return res.status(401).send({ message: e.message });
    }
  };

  // update student profile
  static getStudentProfileUpdate = async (req, res) => {
    try {
      const adminId = req.user._id;
      const student = await Students.findOne({
        adminId: adminId,
        studentID: req.params.id,
      });
      if (student) {
        student.isCourseCompleted = true;
        await student.save();
        return res.status(201).send({ status: "ok", data: student });
      } else {


        return res.status(404).send({ message: e.message });
      }

    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting student error!",
      });
    }
  };

  // get profile
  static getStudentProfile = async (req, res) => {
    try {
      const student = await Students.findOne({
        studentID: req.params.id,
      });

      return res.status(201).send({ status: "ok", data: student });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting student error!",
      });
    }
  };

  // get all students

  static getAllStudents = async (req, res) => {
    try {

      const adminId = req.user._id;

      const student = await Students.find({ adminId: adminId });



      return res.status(201).send({ status: "ok", data: student });
    } catch (error) {
      console.log(error);
      return res.status(401).send({
        status: "failed",
        message: "getting student error!",
      });
    }
  };
}
module.exports = AuthUserServices;
