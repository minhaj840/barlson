// it automatically set certiificate before 10 days of completion of internship

const { Students } = require("../models/Student");
const cron = require("node-cron");

// ********* CRON JOB **********//

// const student = await Students.find({})
const taskRunner = cron.schedule("0 0 * * *", async () => {
  const students = await Students.find({});
  students.forEach(async (student) => {
    if (student.isCourseCompleted === false) {
      student.isCourseCompleted = true;
      await students.save();
    }
  });
});
taskRunner.start();
