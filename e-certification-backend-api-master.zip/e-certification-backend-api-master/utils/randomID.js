module.exports.randomID = (digitLength) => {
  let string = "";
  const digits = "0123456789";
  for (let i = 0; i < digitLength; i++) {
    string += digits[Math.floor(Math.random() * digitLength)];
  }

  return string;
};

module.exports.CAMID = () => {
  let string = "";
  const digits = "0123456789";
  for (let i = 0; i < 4; i++) {
    string += digits[Math.floor(Math.random() * 4)];
  }

  const year = new Date().getFullYear();
  const genId = `BQST/CA/${year}/${string}`;
  return genId;
};
