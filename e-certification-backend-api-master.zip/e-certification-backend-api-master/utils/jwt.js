const jwt = require("jsonwebtoken");

const { SECRETS } = require("./config.js");
const { Admins } = require("../models/Admin.js");

module.exports.newToken = (user) => {
  return jwt.sign({ id: user._id }, SECRETS.jwt, {
    expiresIn: SECRETS.jwtExp,
  });
};

module.exports.verifyToken = (token) =>
  new Promise((resolve, reject) => {
    jwt.verify(token, SECRETS.jwt, (err, payload) => {
      if (err) return reject(err);
      resolve(payload);
    });
  });

module.exports.checkUserAuth = async (req, res, next) => {
  let token;
  const Models = req.model;
  const { authorization } = req.headers;
  if (authorization && authorization.startsWith("Bearer")) {
    try {
      token = authorization.split(" ")[1];

      const userId = jwt.verify(token, process.env.JWT_SECRET).id;

      req.user = await Models.findById(userId).select("-password");

      if (!req.user) {
        return res.status(404).send({
          status: "failed",
          message: "User not found or Invalid token",
        });
      }

      next();
    } catch (error) {
      console.log(error);
      res.status(401).send({ status: "failed", message: "Unauthorized User" });
    }
  }
  if (!token) {
    res
      .status(401)
      .send({ status: "failed", message: "Unauthorized User No Token" });
  }
};
