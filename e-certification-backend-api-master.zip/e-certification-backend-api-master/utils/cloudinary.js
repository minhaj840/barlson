const { config, uploader } = require("cloudinary");

const cloudinaryConfig = async (locaFilePath, type) => {
  config({
    cloud_name: "dycuwk9fb",
    api_key: "399194328415622",
    api_secret: "w_ALiIimve9jyEC3Zs04If8_0M0",
  });
  try {
    if (type === "pdf") {
      return uploader
        .upload(locaFilePath, {
          resource_type: "pdf",
        })
        .then((result) => {
          const image = result;
          return image;
        });
    }
    if (type === "csv") {
      return uploader
        .upload(locaFilePath, {
          resource_type: "raw",
        })
        .then((result) => {
          const image = result;
          return image;
        });
    }
    if (type === "image") {
      return uploader
        .upload(locaFilePath, {
          resource_type: "image",
        })
        .then((result) => {
          const image = result;
          return image;
        });
    }
  } catch (err) {
    console.log(err);
    res.status(400).json({
      messge: "someting went wrong while processing your request",
      data: {
        err,
      },
    });
    return null;
  }
};
module.exports = { cloudinaryConfig };
