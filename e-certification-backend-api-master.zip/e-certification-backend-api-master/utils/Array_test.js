const data = [
  {
    Timestamp: "14/10/2023 06:38:52",
    "Email address": "bhanu.spratap01@gmail.com",
    "Are you interested in the Campus Ambassador program": "Yes",
    "Full Name": "Bhanu Pratap ",
    Email: "bhanu.spratap01@gmail.com",
    "Contact No.": "7055673374",
    "College Name": "RAJKIYA ENGINEERING COLLEGE BIJNOR UP ",
    "Graduation completion year": "2023",
    Stream: "Electrical Engineering ",
    "Course Name": "BE/B.Tech",
    "Which all languages you know.": "HTML, CSS, JavaScript, C++, C, Python",
    "Any internship experiences in the past?": "NO",
    "Referral Id:- ": "",
    "Tell me something about yourself.":
      "My Name is BHANU PRATAP, I have done B.Tech with electrical Engineering in july 2023 from Govt. RAJKIYA ENGINEERING COLLEGE BIJNOR. I am passionate  for software industry and I am quick learner.and  i have done my schooling from M.M.Inter college chandpur Bijnor. And my hobbies are playing Football and reading books.\n" +
      "And my father is farmer.",
    "How you came to know about this opportunity?": "Linkdin",
    "Tell us something about your coding journey.":
      "When I was in 3th sem. And python is in my ciriculum. And  when I start   studying python. My interest  is growing up in the coding. And then COVID start. I have no guidance to start  again coding journey. And  then after COVID  i start studying C++ and  my interest is increasing.  But I have to manage my Electrical academic in side. ",
    "Where you see yourself in next 5 years?":
      "I want to see myself in next  5 years  to become a senior software developer in esteemed organisation like as your company.  Where  I  will able  make incredible software and Manage the team. I  will able to take  more responsibility.",
    "Rate yourself on scale of 10 in coding.": "8",
    "How do you rate the internship opportunities in college. ": "1",
    "What do you know about Bqarlson Software Technologies?":
      "Bqarlson software technologies is a creative engineering company offer design and technology solutions.",
    "What all services we provide?":
      "Design and technology solutions on mobile ,  web  and cloud platform ",
    "What is our objective?": "",
  },
  {
    Timestamp: "14/10/2023 07:08:20",
    "Email address": "pilladivyasree2004@gmail.com",
    "Are you interested in the Campus Ambassador program": "Yes",
    "Full Name": "pilla Divya Vidhyasree ",
    Email: "pilladivyasree2004@gmail.com",
    "Contact No.": "8143643391",
    "College Name": "Dadi institute of engineering and technology ",
    "Graduation completion year": "2025",
    Stream: "Artificial intelligence and machine learning ",
    "Course Name": "BE/B.Tech",
    "Which all languages you know.": "HTML, CSS, JavaScript, JAVA, C, Python",
    "Any internship experiences in the past?": "NO",
    "Referral Id:- ": "no ",
    "Tell me something about yourself.":
      "I am aspiring machine learning engineer seeking a chance to prove my skills in internship and also a web developer ",
    "How you came to know about this opportunity?": "Linkdin",
    "Tell us something about your coding journey.":
      "from btech first i started doing coding and started implementing data structures in python java and c languages ",
    "Where you see yourself in next 5 years?": "in a job ",
    "Rate yourself on scale of 10 in coding.": "8",
    "How do you rate the internship opportunities in college. ": "4",
    "What do you know about Bqarlson Software Technologies?":
      "i don't about it",
    "What all services we provide?": "I don't know ",
    "What is our objective?": "to get an internship ",
  },
];

const mapData = data?.map((stud, index) => {
  const des = data[index];
  const email = des["Email"];
  const name = des["Full Name"];
  const contact = des["Contact No."];
  const collgeName = des["College Name"];
  const graduationComplete = des["Graduation completion year"];
  const stream = des["Stream"];
  return {
    email,
    name,
    contact,
    graduationComplete,
    collgeName,
    stream,
  };
});

console.log(mapData);
// Accessing data from the first object
// const firstObject = data[0];
// console.log(firstObject["Full Name"]); // Output: Bhanu Pratap
// console.log(firstObject.Email); // Output: bhanu.spratap01@gmail.com

// // Accessing data from the second object
// const secondObject = data[1];
// console.log(secondObject["Full Name"]); // Output: pilla Divya Vidhyasree
// console.log(secondObject.Email); // Output: pilladivyasree2004@gmail.com
