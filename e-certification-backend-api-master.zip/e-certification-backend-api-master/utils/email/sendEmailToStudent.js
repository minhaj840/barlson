const sendEmail = require("./email");

async function sendEmailToStudent(req, res) {
  try {
    const emails = req.body.state.email;
    let email = emails?.map((email)=>email.value);
    const subject = req.body.state.subject
    const html = req.body.state.html
    const emailMail = {
      email:email,
      subject:subject,
      message:"",
      html:html
    }

    // await sendEmail(email,subject,"",html);
    await sendEmail(emailMail);

    return res.status(201).send({
        status: "success",
        message: "message sent",
      });
  } catch (error) {
    return res.status(401).send({
      status: "failed",
      message: error?.message,
    });
  }
}

module.exports = sendEmailToStudent;
