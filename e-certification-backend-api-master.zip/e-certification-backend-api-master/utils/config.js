const dotenv = require("dotenv");
dotenv.config();

const SECRETS = {
  jwt: process.env.JWT_SECRET,
  jwtExp: "100d",
};

module.exports = { SECRETS };

// previous send grid
// SEND_Grid=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
// SEND_Grid=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
