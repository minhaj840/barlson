module.exports.isAdmin = (req, res, next) => {
  try {
    if (!req.user.roles.includes("admin")) {
      return res
        .status(403)
        .json({ error: "Only admin can access this route" });
    }
    next();
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: "failed",
      message: "Server Error",
      error: err.message,
    });
  }
};
