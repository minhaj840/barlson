const multer  = require('multer')
const path = require('path')


const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './public')
    },
    filename: function (req, file, cb) {
      cb(null, file.originalname)
    }
})


const fileFilter = (req, file, cb) => {
    // Check if the uploaded file has a CSV extension
    const allowedExtensions = ['.csv'];
    const fileExtension = path.extname(file.originalname).toLowerCase();
  
    if (allowedExtensions.includes(fileExtension)) {
      cb(null, true); // Accept the file
    } else {
      cb(new Error('Only CSV files are allowed.'), false); // Reject the file
    }
  };

module.exports. upload = multer({
    storage: storage,
    fileFilter: fileFilter
  });