<template>
  <div class="main-container">
    <h2>Why Choose Us?</h2>
    <p class="left-align md:px-[10%]">
      At B-Qarlson Software Technologies Private Limited, we are a leading web-based
      interactive marketing agency, specializing in top-notch websites and
      impactful online campaigns. Our strategic approach, cutting-edge
      technology, and global reach ensure superior brand experiences and
      measurable results for our clients. Join us on the path to digital triumph
      and elevate your brand's online presence today!are you there One-Stop
      Solution: As your one-stop digital partner, we offer a complete range of
      services to meet all your digital requirements under one roof.
      <br />
      <strong class="text-white pr-2">Expertise and Innovation:</strong>
      Our seasoned professionals bring a wealth of expertise and innovative
      ideas to transform your vision into reality.
      <br />
      <strong class="text-white pr-2">Client-Centric Approach:</strong> Your
      success is our priority. We tailor our solutions to align with your
      specific goals and objectives.
      <br />
      <strong class="text-white pr-2">Result-Driven Strategies:</strong>
      We believe in data-driven decision-making. Our strategies are designed to
      deliver measurable results and maximum return on investment.
    </p>
    <div class="grid-layout bg-[red] whitespace-nowrap">
      <div class="card">
        <img src="./images/img_1.webp" alt="" />
        <h5>EXPERIENCE</h5>
        <span>5+ years in industry</span>
      </div>

      <div class="card">
        <img src="./images/img_2.webp" alt="" />
        <h5>INNOVATION</h5>
        <span>100+ Websites and applications designed</span>
      </div>

      <div class="card">
        <img src="./images/img_3.webp" alt="" />
        <h5>CUSTOMER BASE</h5>
        <span>100+ Satisfied customers worldwide</span>
      </div>

      <div class="card">
        <img src="./images/img_4.webp" alt="" />
        <h5>WORK</h5>
        <span>100+ Web applications</span>
      </div>

      <div class="card">
        <img src="./images/img_5.webp" alt="" />
        <h5>EXPERTISE</h5>
        <span>100+ E-comm Payment Gateway integrations</span>
      </div>

      <div class="card">
        <img src="./images/img_6.webp" alt="" />
        <h5>LOCAL - GLOBAL</h5>
        <span>100+ Man years in experience</span>
      </div>
    </div>
    <h2>Our Clients</h2>
    <p class="pb-8 md:px-[10%]">
      Our Work, Projects and Portfolio speaks for itself. With our strong global
      delivery model, we serve clients worldwide across USA, UK, Europe,
      Singapore, Australia, Canada, Dubai - UAE, Sri Lanka. Our spectrum of
      services include graphic designs, Social Media Designs and websites to
      highly complex database driven applications, mobile apps, digital
      marketing projects and global server hosting. E-Website Provider can
      design and build an end-to-end digital solutions that will work for you
      and your clients.
    </p>
    <img class="map" src="./images/our-presence-map.png" alt="map source" />
  </div>
</template>
<style scoped>
.main-container {
  display: flex;
  align-items: center;
  flex-direction: column;
  background-color: #000;
  color: #fff;
}

.card {
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  padding: 16px;
}
.card h5 {
  padding: 8px 0;
}
.map {
  height: 400px;
  margin: 0 auto;
}
</style>
