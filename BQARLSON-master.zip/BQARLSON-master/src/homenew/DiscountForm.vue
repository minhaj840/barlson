<template>
  <div class="bg-white rounded-[8px] text-[#000]">
    <div class="bg-[yellow] text-center rounded-[8px] p-2">
      <h3>Get Your Exclusive Discounted Offer</h3>
      <h4>Please fill out the form.</h4>
    </div>
    <p class="highlight">Choose offer for</p>
    <form action="" class="grid sm:grid-cols-2 gap-4 p-4">
      <span><input type="radio" name="yes" /> Free Domain Registration</span>
      <span><input type="radio" name="yes" /> Free SEO Audit</span>
      <input type="text" placeholder="Name" />
      <input type="email" placeholder="Email" />
      <input type="text" placeholder="Company" />
      <input type="number" name="" id="" placeholder="Phone NO." />
      <input type="text" placeholder="Service" />
      <input type="text" placeholder="Comments" />
      <button class="p-2 rounded-[8px] bg-[yellow]">SEND</button>
      <button class="p-2 rounded-[8px] bg-[yellow]">RESET</button>
    </form>
  </div>
</template>
